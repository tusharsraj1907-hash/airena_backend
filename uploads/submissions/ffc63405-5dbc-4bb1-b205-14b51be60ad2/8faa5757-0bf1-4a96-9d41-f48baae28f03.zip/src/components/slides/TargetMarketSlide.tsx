import React from 'react';
import { Building2, Phone, Globe, Users, Shield, Zap, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

export function TargetMarketSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          🎯 Target Market Analysis
        </h1>
        <p className="text-xl text-gray-600">High-impact industries with massive call volumes</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-blue-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">Banking & Finance</CardTitle>
            <Badge variant="secondary" className="mx-auto">High Priority</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Account inquiries & balance checks</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Fraud alerts & security verification</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Claims processing automation</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-blue-600">JPMorgan Chase, HSBC, Bank of America</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">💰 $50K+ savings per month</Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-green-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">Telecommunications</CardTitle>
            <Badge variant="secondary" className="mx-auto bg-green-100 text-green-800">High Volume</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Technical support & troubleshooting</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Billing inquiries & payment</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Service activation & upgrades</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-green-600">Verizon, AT&T, T-Mobile</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">📞 1M+ calls handled/month</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-purple-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">E-commerce & Retail</CardTitle>
            <Badge variant="secondary" className="mx-auto bg-purple-100 text-purple-800">Fast Growth</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Order tracking & status updates</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Return & refund processing</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Product information & support</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-purple-600">Amazon, Walmart, Target</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">🚀 24/7 peak season ready</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-orange-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">Travel & Hospitality</CardTitle>
            <Badge variant="secondary" className="mx-auto bg-orange-100 text-orange-800">24/7 Need</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Booking assistance & modifications</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Check-in support & room service</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Cancellations & rebooking</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-orange-600">Marriott, Hilton, Delta Airlines</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">🌍 Multi-language support</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-red-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">Insurance</CardTitle>
            <Badge variant="secondary" className="mx-auto bg-red-100 text-red-800">Critical Need</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Claims processing & status</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Policy inquiries & updates</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Emergency claim reporting</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-red-600">State Farm, Allstate, Progressive</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">⚡ Emergency response ready</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-2xl transition-all duration-300 border-2 hover:border-yellow-300 hover:scale-105">
          <CardHeader className="pb-4">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-xl">Utilities & Energy</CardTitle>
            <Badge variant="secondary" className="mx-auto bg-yellow-100 text-yellow-800">Emergency Ready</Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Outage reporting & updates</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Service requests & scheduling</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Billing support & payments</span>
              </div>
            </div>
            <div className="pt-3 border-t">
              <p className="text-xs text-gray-500 font-medium">TARGET COMPANIES:</p>
              <p className="text-xs text-yellow-600">ConEd, PG&E, Duke Energy</p>
            </div>
            <div className="text-center">
              <Badge variant="outline" className="text-xs">🔧 24/7 emergency handling</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center mt-12 p-8 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 rounded-2xl border-2 border-blue-200">
        <h3 className="text-3xl font-bold text-gray-800 mb-4">🎯 Combined Market Potential</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          <div>
            <div className="text-3xl font-bold text-blue-600">$2.5T+</div>
            <div className="text-sm text-gray-600">Total Industry Revenue</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-green-600">15-25%</div>
            <div className="text-sm text-gray-600">Support Cost Ratio</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-600">$375B+</div>
            <div className="text-sm text-gray-600">Addressable Market</div>
          </div>
        </div>
      </div>
    </div>
  );
}