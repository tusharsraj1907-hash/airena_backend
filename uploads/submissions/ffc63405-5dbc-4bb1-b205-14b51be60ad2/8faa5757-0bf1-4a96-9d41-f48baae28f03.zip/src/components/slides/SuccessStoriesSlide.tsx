import React from 'react';
import { Building2, Phone, Globe, Shield, CheckCircle, DollarSign, Star, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

export function SuccessStoriesSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
          🏆 Success Stories & Results
        </h1>
        <p className="text-xl text-gray-600">Real clients, real results, real ROI</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-2 border-green-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-green-800">Regional Bank</CardTitle>
                <p className="text-sm text-green-600">50K+ customers</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-green-200 rounded-lg">
                <div className="text-2xl font-bold text-green-800">73%</div>
                <div className="text-xs text-green-600">Cost Reduction</div>
              </div>
              <div className="text-center p-3 bg-green-200 rounded-lg">
                <div className="text-2xl font-bold text-green-800">2.1s</div>
                <div className="text-xs text-green-600">Avg Response</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Handled 85% of account inquiries</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Customer satisfaction up 34%</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">$240K monthly savings</span>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-green-100 text-green-800">
              ROI achieved in 1.8 months
            </Badge>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-blue-800">Telecom Provider</CardTitle>
                <p className="text-sm text-blue-600">2M+ subscribers</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-200 rounded-lg">
                <div className="text-2xl font-bold text-blue-800">67%</div>
                <div className="text-xs text-blue-600">Call Resolution</div>
              </div>
              <div className="text-center p-3 bg-blue-200 rounded-lg">
                <div className="text-2xl font-bold text-blue-800">45K</div>
                <div className="text-xs text-blue-600">Calls/Day</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Technical support automation</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Billing inquiry resolution</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">$1.2M annual savings</span>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-blue-100 text-blue-800">
              Handling 45,000+ calls daily
            </Badge>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-purple-800">E-commerce Platform</CardTitle>
                <p className="text-sm text-purple-600">500K+ orders/month</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-purple-200 rounded-lg">
                <div className="text-2xl font-bold text-purple-800">89%</div>
                <div className="text-xs text-purple-600">Order Tracking</div>
              </div>
              <div className="text-center p-3 bg-purple-200 rounded-lg">
                <div className="text-2xl font-bold text-purple-800">24/7</div>
                <div className="text-xs text-purple-600">Coverage</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Peak season ready (Black Friday)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Return process automation</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Multi-language support</span>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-purple-100 text-purple-800">
              Zero downtime during peaks
            </Badge>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-orange-600 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-orange-800">Insurance Company</CardTitle>
                <p className="text-sm text-orange-600">200K+ policies</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-orange-200 rounded-lg">
                <div className="text-2xl font-bold text-orange-800">78%</div>
                <div className="text-xs text-orange-600">Claims Auto</div>
              </div>
              <div className="text-center p-3 bg-orange-200 rounded-lg">
                <div className="text-2xl font-bold text-orange-800">4.8★</div>
                <div className="text-xs text-orange-600">Satisfaction</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">First Notice of Loss processing</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Policy inquiry automation</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Emergency claim routing</span>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-orange-100 text-orange-800">
              Critical claims never missed
            </Badge>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-12 p-8 bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 text-white rounded-2xl">
        <h3 className="text-4xl font-bold text-center mb-8">📊 Aggregate Results Across All Clients</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <DollarSign className="w-8 h-8" />
            </div>
            <div className="text-3xl font-bold mb-2">$8.7M+</div>
            <div className="text-lg">Total Savings Generated</div>
            <div className="text-sm opacity-80 mt-1">Across all implementations</div>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <Phone className="w-8 h-8" />
            </div>
            <div className="text-3xl font-bold mb-2">2.1M+</div>
            <div className="text-lg">Calls Handled</div>
            <div className="text-sm opacity-80 mt-1">Monthly average</div>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <Star className="w-8 h-8" />
            </div>
            <div className="text-3xl font-bold mb-2">4.7★</div>
            <div className="text-lg">Avg Satisfaction</div>
            <div className="text-sm opacity-80 mt-1">Customer rating improvement</div>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <TrendingUp className="w-8 h-8" />
            </div>
            <div className="text-3xl font-bold mb-2">73%</div>
            <div className="text-lg">Avg Cost Reduction</div>
            <div className="text-sm opacity-80 mt-1">First-year savings</div>
          </div>
        </div>
      </div>
    </div>
  );
}