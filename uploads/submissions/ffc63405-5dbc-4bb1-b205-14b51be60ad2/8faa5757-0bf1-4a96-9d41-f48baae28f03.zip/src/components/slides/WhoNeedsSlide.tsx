import React from 'react';
import { DollarSign, Users, Clock, TrendingUp, Zap, BarChart3, Star } from 'lucide-react';
import { Card, CardContent } from '../ui/card';

export function WhoNeedsSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent mb-4">
          🔥 Who DESPERATELY Needs AI Voice Agents?
        </h1>
        <p className="text-xl text-gray-600">The crisis is real, the solution is here</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-red-600 flex items-center">
            <span className="text-4xl mr-3">🚨</span>
            Critical Pain Points
          </h2>
          <div className="space-y-4">
            <Card className="bg-gradient-to-r from-red-50 to-red-100 border-2 border-red-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-red-800 text-lg">Skyrocketing Costs</h3>
                    <p className="text-red-700 text-sm mt-1">24/7 support costs $150K-500K+ per month</p>
                    <div className="mt-3 p-3 bg-red-200 rounded-lg">
                      <p className="text-xs text-red-800 font-medium">Average cost per call: $6-15 | AI cost: $0.50-2.00</p>
                      <p className="text-xs text-red-600 mt-1">That's 75-90% potential savings!</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-2 border-orange-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-orange-800 text-lg">Scaling Nightmare</h3>
                    <p className="text-orange-700 text-sm mt-1">Can't hire fast enough, training takes months</p>
                    <div className="mt-3 p-3 bg-orange-200 rounded-lg">
                      <p className="text-xs text-orange-800 font-medium">Hiring time: 2-3 months | Training: 6-8 weeks</p>
                      <p className="text-xs text-orange-600 mt-1">AI deployment: 2-4 weeks total!</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-2 border-yellow-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-yellow-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-yellow-800 text-lg">Customer Expectations</h3>
                    <p className="text-yellow-700 text-sm mt-1">Instant response demanded, patience gone</p>
                    <div className="mt-3 p-3 bg-yellow-200 rounded-lg">
                      <p className="text-xs text-yellow-800 font-medium">Expected wait time: &lt;30 seconds</p>
                      <p className="text-xs text-yellow-600 mt-1">Current average: 3-8 minutes</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-2 border-purple-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-purple-800 text-lg">Quality Inconsistency</h3>
                    <p className="text-purple-700 text-sm mt-1">Human errors, mood variations, knowledge gaps</p>
                    <div className="mt-3 p-3 bg-purple-200 rounded-lg">
                      <p className="text-xs text-purple-800 font-medium">Human accuracy: 70-85% | AI accuracy: 95%+</p>
                      <p className="text-xs text-purple-600 mt-1">Consistent quality, every single time</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-green-600 flex items-center">
            <span className="text-4xl mr-3">💡</span>
            Our Game-Changing Solution
          </h2>
          <div className="space-y-4">
            <Card className="bg-gradient-to-r from-green-50 to-emerald-100 border-2 border-green-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-green-800 text-lg">Lightning Fast Response</h3>
                    <p className="text-green-700 text-sm mt-1">Instant pickup, 24/7 availability, zero wait</p>
                    <div className="mt-3 p-3 bg-green-200 rounded-lg">
                      <p className="text-xs text-green-800 font-medium">Response time: &lt;500ms consistently</p>
                      <p className="text-xs text-green-600 mt-1">Never a busy signal, never a queue</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-blue-800 text-lg">Massive Cost Reduction</h3>
                    <p className="text-blue-700 text-sm mt-1">60-80% operational savings immediately</p>
                    <div className="mt-3 p-3 bg-blue-200 rounded-lg">
                      <p className="text-xs text-blue-800 font-medium">ROI typically achieved in 2-4 months</p>
                      <p className="text-xs text-blue-600 mt-1">$500K support budget → $125K savings annually</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-2 border-purple-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <BarChart3 className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-purple-800 text-lg">Unlimited Scalability</h3>
                    <p className="text-purple-700 text-sm mt-1">Handle 10x call volume without hiring</p>
                    <div className="mt-3 p-3 bg-purple-200 rounded-lg">
                      <p className="text-xs text-purple-800 font-medium">Scale from 100 to 100,000 calls instantly</p>
                      <p className="text-xs text-purple-600 mt-1">Peak season? Black Friday? No problem.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-indigo-50 to-indigo-100 border-2 border-indigo-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-indigo-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Star className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-indigo-800 text-lg">Perfect Consistency</h3>
                    <p className="text-indigo-700 text-sm mt-1">Same high quality, every interaction</p>
                    <div className="mt-3 p-3 bg-indigo-200 rounded-lg">
                      <p className="text-xs text-indigo-800 font-medium">95%+ accuracy, continuous learning</p>
                      <p className="text-xs text-indigo-600 mt-1">No bad days, no training gaps</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      <div className="mt-12 p-8 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 text-white rounded-2xl">
        <h3 className="text-4xl font-bold text-center mb-6">⚡ The Transformation is IMMEDIATE</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-5xl font-bold mb-2">60-80%</div>
            <div className="text-xl">Cost Reduction</div>
            <div className="text-sm opacity-90 mt-2">From day one deployment</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold mb-2">&lt;500ms</div>
            <div className="text-xl">Response Time</div>
            <div className="text-sm opacity-90 mt-2">Every single call, guaranteed</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold mb-2">24/7</div>
            <div className="text-xl">Availability</div>
            <div className="text-sm opacity-90 mt-2">Never miss another customer</div>
          </div>
        </div>
      </div>
    </div>
  );
}