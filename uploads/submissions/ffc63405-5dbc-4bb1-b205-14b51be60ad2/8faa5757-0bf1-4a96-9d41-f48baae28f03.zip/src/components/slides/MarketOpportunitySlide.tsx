import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Progress } from '../ui/progress';

export function MarketOpportunitySlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-green-500 to-blue-600 bg-clip-text text-transparent mb-4">
          🚀 Explosive Market Opportunity
        </h1>
        <p className="text-xl text-gray-600">The AI Voice Agent revolution is happening NOW</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Market Size & Growth 📈</h2>
          <Card className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 border-2 border-blue-200 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-lg text-gray-700 font-medium">Voice AI Agents Market</p>
                  <p className="text-4xl font-bold text-blue-600">$2.4B → $47.5B</p>
                  <p className="text-xl text-green-600 font-semibold">34.8% CAGR</p>
                </div>
                <div className="text-6xl">🚀</div>
              </div>
              <Progress value={85} className="mb-2" />
              <p className="text-sm text-gray-600">Growth trajectory: Exponential</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 border-2 border-green-200 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-lg text-gray-700 font-medium">Voice Assistants</p>
                  <p className="text-4xl font-bold text-green-600">$5.35B → $35.51B</p>
                  <p className="text-xl text-green-600 font-semibold">29.45% CAGR</p>
                </div>
                <div className="text-6xl">🎯</div>
              </div>
              <Progress value={75} className="mb-2" />
              <p className="text-sm text-gray-600">Massive untapped potential</p>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Why RIGHT NOW? ⏰</h2>
          <div className="space-y-6">
            <div className="flex items-start space-x-4 p-4 bg-red-50 rounded-xl border-l-4 border-red-400">
              <div className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-bold">1</span>
              </div>
              <div>
                <h3 className="font-bold text-red-800">Cost Crisis</h3>
                <p className="text-red-700">Customer service costs rising 15-20% annually</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 p-4 bg-orange-50 rounded-xl border-l-4 border-orange-400">
              <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-bold">2</span>
              </div>
              <div>
                <h3 className="font-bold text-orange-800">24/7 Demand</h3>
                <p className="text-orange-700">Customers expect instant, round-the-clock support</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 p-4 bg-green-50 rounded-xl border-l-4 border-green-400">
              <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-bold">3</span>
              </div>
              <div>
                <h3 className="font-bold text-green-800">AI Maturity</h3>
                <p className="text-green-700">Technology finally ready for enterprise deployment</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 p-4 bg-blue-50 rounded-xl border-l-4 border-blue-400">
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-bold">4</span>
              </div>
              <div>
                <h3 className="font-bold text-blue-800">Competitive Advantage</h3>
                <p className="text-blue-700">Early adopters gaining significant market advantage</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-center mt-12 p-8 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl border-2 border-yellow-200">
        <h3 className="text-3xl font-bold text-orange-800 mb-4">⚡ The Perfect Storm</h3>
        <p className="text-xl text-orange-700">Rising costs + Customer expectations + Mature AI = MASSIVE OPPORTUNITY</p>
      </div>
    </div>
  );
}