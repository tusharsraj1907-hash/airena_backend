import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Target, Phone, BarChart3 } from 'lucide-react';

export function MarketSegmentsSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          Market Segments Deep Dive
        </h1>
        <p className="text-xl text-gray-600">Understanding the $47.5B opportunity breakdown</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-800">5 Key Market Segments</h2>
          <div className="space-y-4">
            <Card className="bg-gradient-to-r from-blue-50 to-blue-100 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-blue-800">Voice AI Agents</h3>
                    <p className="text-sm text-blue-600">$2.4B → $47.5B</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="bg-blue-200 text-blue-800">34.8% CAGR</Badge>
                  </div>
                </div>
                <Progress value={35} className="mt-3" />
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-green-50 to-green-100 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-green-800">Voice Assistants</h3>
                    <p className="text-sm text-green-600">$5.35B → $35.51B</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="bg-green-200 text-green-800">29.45% CAGR</Badge>
                  </div>
                </div>
                <Progress value={29} className="mt-3" />
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-purple-800">AI Voice Generators</h3>
                    <p className="text-sm text-purple-600">$3.20B → $40.25B</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="bg-purple-200 text-purple-800">32.51% CAGR</Badge>
                  </div>
                </div>
                <Progress value={32} className="mt-3" />
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-orange-50 to-orange-100 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-orange-800">Speech Recognition</h3>
                    <p className="text-sm text-orange-600">$8.77B → $23.67B</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="bg-orange-200 text-orange-800">17.99% CAGR</Badge>
                  </div>
                </div>
                <Progress value={18} className="mt-3" />
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-red-50 to-red-100 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-red-800">Voice Commerce</h3>
                    <p className="text-sm text-red-600">$42.75B → Growing</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="bg-red-200 text-red-800">24.6% CAGR</Badge>
                  </div>
                </div>
                <Progress value={24} className="mt-3" />
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-800">Our Sweet Spot</h2>
          <Card className="bg-gradient-to-br from-blue-500 to-purple-600 text-white p-8">
            <div className="space-y-4">
              <div className="text-center">
                <Phone className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-2xl font-bold">Voice AI Agents</h3>
                <p className="text-lg">Our Primary Focus</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm">• Highest growth potential (34.8% CAGR)</p>
                <p className="text-sm">• Perfect timing for market entry</p>
                <p className="text-sm">• Massive customer need</p>
                <p className="text-sm">• Technology readiness achieved</p>
              </div>
            </div>
          </Card>
          
          <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-800 flex items-center">
                <Target className="w-6 h-6 mr-2" />
                Market Entry Strategy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-yellow-700">
                <li>✅ Focus on Voice AI Agents (34.8% CAGR)</li>
                <li>✅ Leverage Speech Recognition capabilities</li>
                <li>✅ Integrate Voice Assistant features</li>
                <li>✅ Expand into Voice Commerce</li>
              </ul>
            </CardContent>
          </Card>
          
          <div className="text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border-2 border-green-200">
            <h3 className="text-2xl font-bold text-green-800 mb-2">🎯 Total Addressable Market</h3>
            <p className="text-4xl font-bold text-green-600">$147B+ by 2034</p>
            <p className="text-lg text-green-700">Across all voice AI segments</p>
          </div>
        </div>
      </div>
    </div>
  );
}