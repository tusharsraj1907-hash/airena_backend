import React from 'react';
import { Globe, TrendingUp, Shield, Target, Star, Brain, Users2, Gauge } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

export function RegionalInsightsSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          🌍 Global Regional Insights
        </h1>
        <p className="text-xl text-gray-600">Strategic market entry across key regions</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <span>North America 🇺🇸</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-3xl text-blue-600">~40%</span>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">Market Leader</Badge>
            </div>
            <p className="text-gray-700">Dominant market share with early tech adoption</p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-yellow-500" />
                <span className="text-sm">Large enterprise concentration</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-green-500">💰</span>
                <span className="text-sm">High support costs (average $45/hour)</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-blue-500">🚀</span>
                <span className="text-sm">AI-first mindset established</span>
              </div>
            </div>
            <Progress value={85} className="mt-4" />
            <p className="text-sm text-gray-600">Market Maturity: 85%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span>Asia-Pacific 🌏</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-3xl text-green-600">Fastest</span>
              <Badge variant="secondary" className="bg-green-100 text-green-800">🚀 High Growth</Badge>
            </div>
            <p className="text-gray-700">53% of leaders already implementing AI agents</p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Brain className="w-4 h-4 text-purple-500" />
                <span className="text-sm">Rapid digitization across China, India, Japan</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users2 className="w-4 h-4 text-blue-500" />
                <span className="text-sm">Massive population = huge call volumes</span>
              </div>
              <div className="flex items-center space-x-2">
                <Gauge className="w-4 h-4 text-orange-500" />
                <span className="text-sm">Government-backed AI initiatives</span>
              </div>
            </div>
            <Progress value={70} className="mt-4" />
            <p className="text-sm text-gray-600">Growth Momentum: 70%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span>Europe 🇪🇺</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-3xl text-purple-600">3rd</span>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800">Compliance Focus</Badge>
            </div>
            <p className="text-gray-700">Strong market with regulatory considerations</p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <span className="text-red-500">🔒</span>
                <span className="text-sm">GDPR & AI Act compliance ready</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-blue-500">🏦</span>
                <span className="text-sm">Strong financial services sector</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-yellow-500">🏆</span>
                <span className="text-sm">Quality-focused market</span>
              </div>
            </div>
            <Progress value={60} className="mt-4" />
            <p className="text-sm text-gray-600">Regulatory Readiness: 60%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-2 border-orange-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <span>Emerging Markets 🌎</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-3xl text-orange-600">Future</span>
              <Badge variant="secondary" className="bg-orange-100 text-orange-800">High Potential</Badge>
            </div>
            <p className="text-gray-700">Growing interest in Brazil, Mexico, UAE, Saudi Arabia</p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-sm">Rapid economic growth driving demand</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-blue-500">☎️</span>
                <span className="text-sm">Expanding call center operations</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-purple-500">🚀</span>
                <span className="text-sm">Leapfrog opportunity for AI adoption</span>
              </div>
            </div>
            <Progress value={35} className="mt-4" />
            <p className="text-sm text-gray-600">Market Penetration: 35%</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 p-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl">
        <h3 className="text-3xl font-bold text-center mb-6">🎯 Our Go-to-Market Strategy</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <span className="text-2xl">🚀</span>
            </div>
            <h4 className="text-xl font-bold mb-2">Phase 1: North America</h4>
            <p className="text-sm opacity-90">Established market, high willingness to pay</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <span className="text-2xl">🌏</span>
            </div>
            <h4 className="text-xl font-bold mb-2">Phase 2: Asia-Pacific</h4>
            <p className="text-sm opacity-90">Fastest growth, massive scale opportunity</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-4">
              <span className="text-2xl">🌍</span>
            </div>
            <h4 className="text-xl font-bold mb-2">Phase 3: Global Expansion</h4>
            <p className="text-sm opacity-90">Europe + emerging markets penetration</p>
          </div>
        </div>
      </div>
    </div>
  );
}