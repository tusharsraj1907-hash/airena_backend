import React from 'react';
import { Globe, Phone } from 'lucide-react';
import { Badge } from '../ui/badge';

export function WelcomeSlide() {
  return (
    <div className="text-center space-y-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 opacity-50 rounded-2xl"></div>
      <div className="relative z-10 space-y-6">
        <div className="space-y-4">
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl animate-pulse">
            <Phone className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            AI Voice Agent
          </h1>
          <p className="text-2xl text-gray-700 max-w-3xl mx-auto">
            Revolutionizing Customer Support with Intelligent Voice Automation
          </p>
          <div className="flex justify-center space-x-4">
            <Badge variant="secondary" className="px-6 py-2 text-lg">🚀 Next-Gen Technology</Badge>
            <Badge variant="secondary" className="px-6 py-2 text-lg">💰 60% Cost Reduction</Badge>
            <Badge variant="secondary" className="px-6 py-2 text-lg">⚡ Instant Deployment</Badge>
          </div>
        </div>
        <div className="flex flex-col items-center space-y-4">
          <div className="text-lg text-gray-500 uppercase tracking-wider">Proudly Presented by</div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">Nagorik Technologies</h2>
          <Badge variant="outline" className="px-6 py-2 text-lg">
            <Globe className="w-4 h-4 mr-2" />
            www.nagorik.tech
          </Badge>
          <div className="flex items-center space-x-6 mt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">4.6M+</div>
              <div className="text-sm text-gray-600">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">230+</div>
              <div className="text-sm text-gray-600">Partners</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">30+</div>
              <div className="text-sm text-gray-600">Services</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}