import React from 'react';
import { Globe, Users, Award, Shield, BarChart3 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

export function CompanyOverviewSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          Nagorik Technologies at a Glance
        </h1>
        <p className="text-xl text-gray-600">Trusted by millions, powered by innovation</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="text-center hover:shadow-2xl transition-all duration-300 border-2 hover:border-blue-200">
          <CardHeader className="pb-4">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Globe className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">30+ Global Services</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Diverse portfolio across multiple industries</p>
            <div className="flex justify-center space-x-2">
              <Badge variant="outline">Gaming</Badge>
              <Badge variant="outline">VPN</Badge>
              <Badge variant="outline">EdTech</Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card className="text-center hover:shadow-2xl transition-all duration-300 border-2 hover:border-green-200">
          <CardHeader className="pb-4">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Users className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">4.6M+ Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">22 games with massive user engagement</p>
            <Progress value={92} className="mb-2" />
            <p className="text-sm text-gray-500">92% User Retention Rate</p>
          </CardContent>
        </Card>
        
        <Card className="text-center hover:shadow-2xl transition-all duration-300 border-2 hover:border-purple-200">
          <CardHeader className="pb-4">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Award className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">230+ Partners</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Extensive loyalty partner network</p>
            <div className="flex justify-center">
              <Badge variant="secondary" className="bg-purple-100 text-purple-800">Global Reach</Badge>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-8">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-blue-800">2 Global VPN Services</h3>
                <p className="text-blue-600">108K+ Paid Subscribers Worldwide</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
          <CardContent className="p-8">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-green-800">Largest Exam Inventory</h3>
                <p className="text-green-600">Competitive Exam Question Database</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center mt-8 p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Why This Matters for AI Voice Agents</h3>
        <p className="text-lg text-gray-600">Our proven track record in handling millions of users and complex integrations makes us the ideal partner for your AI voice automation needs.</p>
      </div>
    </div>
  );
}