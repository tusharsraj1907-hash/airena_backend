import React from 'react';
import { PlayCircle, Users, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';

export function ConnectSlide() {
  return (
    <div className="text-center space-y-8">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Ready to Transform Your Customer Support?</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Join the AI revolution and reduce your support costs by 60% while improving customer satisfaction.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50">
          <CardHeader>
            <PlayCircle className="w-12 h-12 mx-auto text-blue-600" />
            <CardTitle>See Our Demo</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Experience our AI Voice Agent in action</p>
            <Button 
              className="w-full" 
              onClick={() => window.open('https://cs-agent-dashboard.vercel.app/', '_blank')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              View Live Demo
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-blue-50">
          <CardHeader>
            <Users className="w-12 h-12 mx-auto text-green-600" />
            <CardTitle>Get In Touch</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Let's discuss your specific needs</p>
            <div className="space-y-2">
              <p className="text-sm"><strong>Arman Hoque</strong></p>
              <p className="text-sm">VP, Product & Marketing</p>
              <p className="text-sm text-blue-600">arman@nagorik.tech</p>
              <p className="text-sm">+880 0179 9994854</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Why Wait?</h2>
        <div className="flex justify-center space-x-8 text-center">
          <div>
            <div className="text-3xl font-bold text-blue-600">60%</div>
            <div className="text-sm text-gray-600">Cost Reduction</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-green-600">24/7</div>
            <div className="text-sm text-gray-600">Availability</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-600">85%+</div>
            <div className="text-sm text-gray-600">Resolution Rate</div>
          </div>
        </div>
      </div>
    </div>
  );
}