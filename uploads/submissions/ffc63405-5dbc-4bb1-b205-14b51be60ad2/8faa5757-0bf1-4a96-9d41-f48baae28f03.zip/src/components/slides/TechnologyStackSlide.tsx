import React from 'react';
import { Brain, Phone, Shield, BarChart3, Building2, CheckCircle, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

export function TechnologyStackSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          ⚙️ Our Technology Stack
        </h1>
        <p className="text-xl text-gray-600">Enterprise-grade AI infrastructure powering millions of conversations</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span>AI & NLP Core</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-blue-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="font-semibold text-blue-800">Advanced Language Models</h4>
                  <p className="text-xs text-blue-600">GPT-4 Turbo, Claude, Custom Fine-tuned Models</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-blue-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="font-semibold text-blue-800">Real-time Speech Processing</h4>
                  <p className="text-xs text-blue-600">Google Speech API, Azure Cognitive Services</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-blue-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="font-semibold text-blue-800">Multi-language Support</h4>
                  <p className="text-xs text-blue-600">50+ languages with dialect recognition</p>
                </div>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-blue-100 text-blue-800">
              &lt;500ms response latency guaranteed
            </Badge>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 hover:shadow-2xl transition-all duration-300">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <span>Voice Infrastructure</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-green-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <h4 className="font-semibold text-green-800">Global Telephony Network</h4>
                  <p className="text-xs text-green-600">Twilio, Vonage, AWS Connect Integration</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-green-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <h4 className="font-semibold text-green-800">HD Voice Quality</h4>
                  <p className="text-xs text-green-600">Crystal clear audio with noise cancellation</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-green-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <h4 className="font-semibold text-green-800">Auto-scaling Infrastructure</h4>
                  <p className="text-xs text-green-600">Handle 100 to 100,000+ concurrent calls</p>
                </div>
              </div>
            </div>
            <Badge variant="outline" className="w-full justify-center bg-green-100 text-green-800">
              99.9% uptime SLA with redundancy
            </Badge>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-purple-800">Security & Compliance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-purple-600" />
                <span className="text-sm">SOC 2 Type II Certified</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-purple-600" />
                <span className="text-sm">GDPR & CCPA Compliant</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-purple-600" />
                <span className="text-sm">End-to-end Encryption</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-purple-600" />
                <span className="text-sm">PCI DSS Level 1</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="w-12 h-12 bg-orange-600 rounded-xl flex items-center justify-center mx-auto">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-orange-800">Analytics & Intelligence</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-orange-600" />
                <span className="text-sm">Real-time Dashboards</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-orange-600" />
                <span className="text-sm">Sentiment Analysis</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-orange-600" />
                <span className="text-sm">Performance Metrics</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-orange-600" />
                <span className="text-sm">Predictive Insights</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 border-2 border-indigo-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center mx-auto">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-center text-indigo-800">Integration Platform</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-indigo-600" />
                <span className="text-sm">CRM Integration</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-indigo-600" />
                <span className="text-sm">ERP Systems</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-indigo-600" />
                <span className="text-sm">Custom APIs</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-indigo-600" />
                <span className="text-sm">Webhook Support</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white p-8 rounded-2xl">
        <h3 className="text-3xl font-bold text-center mb-8">🏗️ Architecture Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-blue-600 rounded-2xl flex items-center justify-center mb-4">
              <Phone className="w-8 h-8" />
            </div>
            <h4 className="font-bold mb-2">Voice Gateway</h4>
            <p className="text-sm opacity-80">Global telephony network with intelligent routing</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-green-600 rounded-2xl flex items-center justify-center mb-4">
              <Brain className="w-8 h-8" />
            </div>
            <h4 className="font-bold mb-2">AI Processing</h4>
            <p className="text-sm opacity-80">Advanced NLP with context understanding</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-purple-600 rounded-2xl flex items-center justify-center mb-4">
              <Building2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold mb-2">Business Logic</h4>
            <p className="text-sm opacity-80">Custom workflows and integration layer</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-orange-600 rounded-2xl flex items-center justify-center mb-4">
              <BarChart3 className="w-8 h-8" />
            </div>
            <h4 className="font-bold mb-2">Analytics Engine</h4>
            <p className="text-sm opacity-80">Real-time insights and performance monitoring</p>
          </div>
        </div>
      </div>
      
      <div className="text-center mt-12 p-8 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 rounded-2xl border-2 border-blue-200">
        <h3 className="text-3xl font-bold text-gray-800 mb-4">🚀 Why Our Tech Stack Matters</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="text-2xl font-bold text-blue-600 mb-2">99.9%</div>
            <div className="font-semibold">Uptime Guarantee</div>
            <div className="text-sm text-gray-600 mt-1">Enterprise-grade reliability</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-600 mb-2">&lt;500ms</div>
            <div className="font-semibold">Response Latency</div>
            <div className="text-sm text-gray-600 mt-1">Faster than human agents</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600 mb-2">100K+</div>
            <div className="font-semibold">Concurrent Calls</div>
            <div className="text-sm text-gray-600 mt-1">Unlimited scalability</div>
          </div>
        </div>
      </div>
    </div>
  );
}