import React from 'react';
import { CheckCircle, Award, Rocket, Shield, Phone } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

export function CompetitiveLandscapeSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent mb-4">
          ⚔️ Competitive Analysis
        </h1>
        <p className="text-xl text-gray-600">See how we stack up against the competition</p>
      </div>
      
      <div className="overflow-x-auto mb-8">
        <table className="w-full border-collapse border-2 border-gray-300 rounded-lg overflow-hidden">
          <thead>
            <tr className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <th className="border border-gray-300 p-4 text-left font-bold">Provider</th>
              <th className="border border-gray-300 p-4 text-left font-bold">Pricing Model</th>
              <th className="border border-gray-300 p-4 text-left font-bold">Cost/Minute</th>
              <th className="border border-gray-300 p-4 text-left font-bold">Focus</th>
              <th className="border border-gray-300 p-4 text-left font-bold">Key Limitation</th>
            </tr>
          </thead>
          <tbody>
            <tr className="hover:bg-gray-50">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                    <span className="text-white text-xs font-bold">V</span>
                  </div>
                  <span className="font-medium">Vapi.ai</span>
                </div>
              </td>
              <td className="border border-gray-300 p-4">Pay-as-you-go</td>
              <td className="border border-gray-300 p-4 text-red-600 font-semibold">~$0.05/min</td>
              <td className="border border-gray-300 p-4">Developer-focused</td>
              <td className="border border-gray-300 p-4 text-sm text-red-600">DIY only, no managed service</td>
            </tr>
            <tr className="bg-gray-50 hover:bg-gray-100">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <span className="text-white text-xs font-bold">R</span>
                  </div>
                  <span className="font-medium">Retell AI</span>
                </div>
              </td>
              <td className="border border-gray-300 p-4">Pay-as-you-go</td>
              <td className="border border-gray-300 p-4 text-red-600 font-semibold">~$0.07/min</td>
              <td className="border border-gray-300 p-4">No-code builder</td>
              <td className="border border-gray-300 p-4 text-sm text-red-600">Limited enterprise features</td>
            </tr>
            <tr className="hover:bg-gray-50">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                    <span className="text-white text-xs font-bold">A</span>
                  </div>
                  <span className="font-medium">Air.AI</span>
                </div>
              </td>
              <td className="border border-gray-300 p-4">Monthly subscription</td>
              <td className="border border-gray-300 p-4 text-orange-600 font-semibold">$49.99/month</td>
              <td className="border border-gray-300 p-4">Platform license</td>
              <td className="border border-gray-300 p-4 text-sm text-red-600">Hidden costs, basic features</td>
            </tr>
            <tr className="bg-gray-50 hover:bg-gray-100">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                    <span className="text-white text-xs font-bold">T</span>
                  </div>
                  <span className="font-medium">Taalk.ai</span>
                </div>
              </td>
              <td className="border border-gray-300 p-4">Tiered subscription</td>
              <td className="border border-gray-300 p-4 text-red-600 font-semibold">$999-$1,499/mo</td>
              <td className="border border-gray-300 p-4">Multilingual</td>
              <td className="border border-gray-300 p-4 text-sm text-red-600">Very expensive, limited scale</td>
            </tr>
            <tr className="hover:bg-gray-50">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gray-500 rounded-lg flex items-center justify-center">
                    <span className="text-white text-xs font-bold">G</span>
                  </div>
                  <span className="font-medium">Google/IBM</span>
                </div>
              </td>
              <td className="border border-gray-300 p-4">Per query</td>
              <td className="border border-gray-300 p-4 text-yellow-600 font-semibold">$0.005-$0.009/query</td>
              <td className="border border-gray-300 p-4">Cloud platforms</td>
              <td className="border border-gray-300 p-4 text-sm text-red-600">Complex setup, tech expertise required</td>
            </tr>
            <tr className="bg-gradient-to-r from-blue-50 to-purple-50 border-4 border-blue-400 hover:shadow-lg">
              <td className="border border-gray-300 p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                    <Phone className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-bold text-blue-600">Nagorik AI</span>
                  <Badge className="bg-blue-600 text-white">OUR SOLUTION</Badge>
                </div>
              </td>
              <td className="border border-gray-300 p-4 font-semibold text-blue-800">Flexible & Managed</td>
              <td className="border border-gray-300 p-4 text-green-600 font-bold">Competitive + Value</td>
              <td className="border border-gray-300 p-4 font-semibold text-blue-800">Turnkey Enterprise</td>
              <td className="border border-gray-300 p-4 text-sm text-green-600 font-semibold">No limitations - complete solution</td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center text-2xl">
              <span className="text-3xl mr-3">⚠️</span>
              Competitor Weaknesses
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3 p-3 bg-red-200 rounded-lg">
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs">1</span>
                </div>
                <div>
                  <h4 className="font-semibold text-red-800">DIY Approach Only</h4>
                  <p className="text-sm text-red-700">Require internal technical teams and months of setup</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-red-200 rounded-lg">
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs">2</span>
                </div>
                <div>
                  <h4 className="font-semibold text-red-800">Hidden Costs</h4>
                  <p className="text-sm text-red-700">Additional fees for integrations, support, and advanced features</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-red-200 rounded-lg">
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs">3</span>
                </div>
                <div>
                  <h4 className="font-semibold text-red-800">Limited Scalability</h4>
                  <p className="text-sm text-red-700">Performance degrades with high call volumes</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-red-200 rounded-lg">
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs">4</span>
                </div>
                <div>
                  <h4 className="font-semibold text-red-800">No Accountability</h4>
                  <p className="text-sm text-red-700">When things break, you're on your own</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center text-2xl">
              <span className="text-3xl mr-3">🏆</span>
              Our Advantages
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3 p-3 bg-green-200 rounded-lg">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-green-800">Complete Managed Service</h4>
                  <p className="text-sm text-green-700">From consultation to deployment to ongoing optimization</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-green-200 rounded-lg">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-green-800">Transparent Pricing</h4>
                  <p className="text-sm text-green-700">All-inclusive pricing with no hidden fees or surprises</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-green-200 rounded-lg">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-green-800">Proven Scale</h4>
                  <p className="text-sm text-green-700">4.6M+ users across 30+ services - we handle massive volume</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-green-200 rounded-lg">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-green-800">Single Point of Contact</h4>
                  <p className="text-sm text-green-700">We own the entire solution and guarantee results</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-12 p-8 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white rounded-2xl">
        <h3 className="text-4xl font-bold text-center mb-8">🎯 Why We're Different (and Better)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-6">
              <Rocket className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-3">Speed to Value</h4>
            <p className="text-lg opacity-90">2-4 weeks to full deployment vs 3-6 months with competitors</p>
            <Badge variant="secondary" className="mt-3 bg-white text-blue-600">10x Faster</Badge>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-6">
              <Shield className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-3">Risk-Free Guarantee</h4>
            <p className="text-lg opacity-90">We guarantee results with comprehensive SLA protection</p>
            <Badge variant="secondary" className="mt-3 bg-white text-blue-600">Zero Risk</Badge>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-6">
              <Award className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-3">Proven Expertise</h4>
            <p className="text-lg opacity-90">4.6M+ users trust our technology stack and execution</p>
            <Badge variant="secondary" className="mt-3 bg-white text-blue-600">Battle Tested</Badge>
          </div>
        </div>
      </div>
    </div>
  );
}