import React from 'react';
import { Calculator, TrendingUp, Rocket, Target, BarChart3, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

export function ROIAnalysisSlide() {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
          💰 ROI Analysis & Cost Calculator
        </h1>
        <p className="text-xl text-gray-600">See your potential savings with our AI Voice Agent</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center text-2xl">
              <span className="text-3xl mr-3">📈</span>
              Current Costs (Human Agents)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="bg-red-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-red-800">Average Agent Salary</span>
                  <span className="text-2xl font-bold text-red-600">$45K/year</span>
                </div>
                <p className="text-sm text-red-700 mt-1">Plus benefits, training, management overhead</p>
              </div>
              <div className="bg-red-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-red-800">Total Cost per Agent</span>
                  <span className="text-2xl font-bold text-red-600">$65K/year</span>
                </div>
                <p className="text-sm text-red-700 mt-1">Including benefits, training, infrastructure</p>
              </div>
              <div className="bg-red-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-red-800">Cost per Call</span>
                  <span className="text-2xl font-bold text-red-600">$8-15</span>
                </div>
                <p className="text-sm text-red-700 mt-1">Average handling time: 6-12 minutes</p>
              </div>
            </div>
            <div className="text-center pt-4 border-t border-red-300">
              <h3 className="text-xl font-bold text-red-800 mb-2">Monthly Cost for 10K Calls</h3>
              <p className="text-4xl font-bold text-red-600">$80K - $150K</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center text-2xl">
              <span className="text-3xl mr-3">🤖</span>
              AI Agent Costs (Nagorik)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="bg-green-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-green-800">AI Processing Cost</span>
                  <span className="text-2xl font-bold text-green-600">$0.50-2.00</span>
                </div>
                <p className="text-sm text-green-700 mt-1">Per call, including all AI services</p>
              </div>
              <div className="bg-green-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-green-800">Platform & Management</span>
                  <span className="text-2xl font-bold text-green-600">$5K/month</span>
                </div>
                <p className="text-sm text-green-700 mt-1">Fixed cost regardless of call volume</p>
              </div>
              <div className="bg-green-200 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-green-800">Support & Optimization</span>
                  <span className="text-2xl font-bold text-green-600">Included</span>
                </div>
                <p className="text-sm text-green-700 mt-1">No additional charges for support</p>
              </div>
            </div>
            <div className="text-center pt-4 border-t border-green-300">
              <h3 className="text-xl font-bold text-green-800 mb-2">Monthly Cost for 10K Calls</h3>
              <p className="text-4xl font-bold text-green-600">$25K - $35K</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-8 rounded-2xl mb-8">
        <h3 className="text-4xl font-bold text-center mb-8">💸 Your Savings Calculator</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-4">
              <Calculator className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-2">Monthly Savings</h4>
            <p className="text-4xl font-bold">$55K - $115K</p>
            <p className="opacity-90 mt-2">For 10,000 calls per month</p>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-4">
              <TrendingUp className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-2">Annual Savings</h4>
            <p className="text-4xl font-bold">$660K - $1.38M</p>
            <p className="opacity-90 mt-2">Compound savings over time</p>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 mx-auto bg-white bg-opacity-20 rounded-3xl flex items-center justify-center mb-4">
              <Rocket className="w-10 h-10" />
            </div>
            <h4 className="text-2xl font-bold mb-2">ROI Period</h4>
            <p className="text-4xl font-bold">2-4 Months</p>
            <p className="opacity-90 mt-2">Payback period</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center">
              <BarChart3 className="w-6 h-6 mr-2" />
              Sample ROI Scenarios
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="bg-blue-200 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-blue-800">Small Business</h4>
                  <Badge variant="outline" className="text-blue-800">1K calls/month</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Current Cost: <span className="font-bold text-red-600">$8K-15K</span></div>
                  <div>With AI: <span className="font-bold text-green-600">$5.5K-7K</span></div>
                  <div className="col-span-2">Monthly Savings: <span className="font-bold text-blue-800">$2.5K-8K</span></div>
                </div>
              </div>
              
              <div className="bg-blue-200 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-blue-800">Medium Enterprise</h4>
                  <Badge variant="outline" className="text-blue-800">25K calls/month</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Current Cost: <span className="font-bold text-red-600">$200K-375K</span></div>
                  <div>With AI: <span className="font-bold text-green-600">$62K-87K</span></div>
                  <div className="col-span-2">Monthly Savings: <span className="font-bold text-blue-800">$138K-288K</span></div>
                </div>
              </div>
              
              <div className="bg-blue-200 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold text-blue-800">Large Enterprise</h4>
                  <Badge variant="outline" className="text-blue-800">100K calls/month</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Current Cost: <span className="font-bold text-red-600">$800K-1.5M</span></div>
                  <div>With AI: <span className="font-bold text-green-600">$205K-305K</span></div>
                  <div className="col-span-2">Monthly Savings: <span className="font-bold text-blue-800">$595K-1.2M</span></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200">
          <CardHeader>
            <CardTitle className="text-orange-800 flex items-center">
              <Target className="w-6 h-6 mr-2" />
              Additional Benefits (Quantified)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="bg-orange-200 p-3 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Improved Customer Satisfaction</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>CSAT Increase: <span className="font-bold">+25-40%</span></div>
                  <div>NPS Improvement: <span className="font-bold">+15-30 points</span></div>
                </div>
                <p className="text-xs text-orange-700 mt-1">Value: $2-5M in customer lifetime value</p>
              </div>
              
              <div className="bg-orange-200 p-3 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Operational Efficiency</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Response Time: <span className="font-bold">&lt;30 seconds</span></div>
                  <div>First Call Resolution: <span className="font-bold">85%+</span></div>
                </div>
                <p className="text-xs text-orange-700 mt-1">Reduces repeat calls by 60-70%</p>
              </div>
              
              <div className="bg-orange-200 p-3 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">24/7 Availability Impact</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Off-hours Calls: <span className="font-bold">35% of total</span></div>
                  <div>Revenue Protected: <span className="font-bold">$500K-2M</span></div>
                </div>
                <p className="text-xs text-orange-700 mt-1">No more missed opportunities</p>
              </div>
              
              <div className="bg-orange-200 p-3 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">Scaling Flexibility</h4>
                <div className="text-sm">
                  <div>Peak Season Ready: <span className="font-bold">Instant 10x scale</span></div>
                </div>
                <p className="text-xs text-orange-700 mt-1">No hiring costs, no training delays</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="text-center mt-12 p-8 bg-gradient-to-r from-green-50 via-blue-50 to-purple-50 rounded-2xl border-2 border-green-200">
        <h3 className="text-3xl font-bold text-gray-800 mb-4">🎯 Bottom Line Impact</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="text-3xl font-bold text-green-600 mb-2">60-80%</div>
            <div className="font-semibold">Cost Reduction</div>
            <div className="text-sm text-gray-600 mt-1">Immediate operational savings</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-600 mb-2">2-4 Months</div>
            <div className="font-semibold">Payback Period</div>
            <div className="text-sm text-gray-600 mt-1">Faster ROI than any alternative</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-600 mb-2">$1M+</div>
            <div className="font-semibold">Annual Value</div>
            <div className="text-sm text-gray-600 mt-1">For medium-sized operations</div>
          </div>
        </div>
      </div>
    </div>
  );
}