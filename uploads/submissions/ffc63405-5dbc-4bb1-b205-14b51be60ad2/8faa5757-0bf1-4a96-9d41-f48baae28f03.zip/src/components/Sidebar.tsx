import { Sparkles, Mic, Phone, FileText, User, LogOut, BookOpen } from 'lucide-react';
import { Button } from './ui/button';
import { motion } from 'motion/react';

interface SidebarProps {
  user: any;
  activeTab: string;
  onTabChange: (tab: 'speak' | 'call' | 'transcript' | 'profile' | 'knowledge') => void;
  onLogout: () => void;
}

export function Sidebar({ user, activeTab, onTabChange, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'speak', label: 'Speak with Bruno', icon: Mic },
    { id: 'call', label: 'AI Call', icon: Phone },
    { id: 'transcript', label: 'Transcripts', icon: FileText },
    { id: 'knowledge', label: 'Knowledge Base', icon: BookOpen },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="w-64 bg-gradient-to-b from-blue-950 to-indigo-900 text-white flex flex-col shadow-2xl relative overflow-hidden">
      {/* Animated background */}
      <motion.div
        className="absolute top-0 left-0 w-32 h-32 bg-blue-400/10 rounded-full blur-2xl"
        animate={{
          y: [0, 100, 0],
          x: [0, 50, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      {/* Logo */}
      <div className="p-6 border-b border-white/10 relative z-10">
        <div className="flex items-center gap-3">
          <motion.div 
            className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center"
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="w-6 h-6" />
          </motion.div>
          <div>
            <motion.h1 
              className="text-xl"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              BRUNO
            </motion.h1>
            <motion.p 
              className="text-xs text-blue-200"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              AI Tax Assistant
            </motion.p>
          </div>
        </div>
      </div>

      {/* User Info */}
      <motion.div 
        className="p-4 border-b border-white/10 relative z-10"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center gap-3">
          <motion.div 
            className="w-10 h-10 bg-blue-500/30 rounded-full flex items-center justify-center"
            whileHover={{ scale: 1.1 }}
          >
            <User className="w-5 h-5" />
          </motion.div>
          <div className="flex-1 min-w-0">
            <p className="truncate">{user?.name}</p>
            <p className="text-xs text-blue-300 truncate">{user?.email}</p>
          </div>
        </div>
        {user?.role === 'admin' && (
          <motion.div 
            className="mt-2"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.4, type: "spring" }}
          >
            <motion.span 
              className="inline-block px-2 py-1 bg-purple-500/30 rounded text-xs"
              animate={{
                boxShadow: [
                  "0 0 10px rgba(168, 85, 247, 0.3)",
                  "0 0 20px rgba(168, 85, 247, 0.6)",
                  "0 0 10px rgba(168, 85, 247, 0.3)"
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Admin
            </motion.span>
          </motion.div>
        )}
      </motion.div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 relative z-10">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <motion.button
              key={item.id}
              onClick={() => onTabChange(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all relative overflow-hidden ${
                isActive
                  ? 'bg-white/20 text-white'
                  : 'text-blue-200 hover:bg-white/10 hover:text-white'
              }`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
            >
              {isActive && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20"
                  layoutId="activeTab"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <motion.div
                animate={isActive ? { rotate: [0, 5, -5, 0] } : {}}
                transition={{ duration: 0.5 }}
              >
                <Icon className="w-5 h-5 relative z-10" />
              </motion.div>
              <span className="relative z-10">{item.label}</span>
            </motion.button>
          );
        })}
      </nav>

      {/* Logout */}
      <motion.div 
        className="p-4 border-t border-white/10 relative z-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <motion.div whileHover={{ x: 4 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={onLogout}
            variant="ghost"
            className="w-full justify-start text-blue-200 hover:text-white hover:bg-white/10"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}