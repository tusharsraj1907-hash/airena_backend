import { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Search, FileText, ChevronRight, Download } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';

interface KnowledgeBasePageProps {
  user: any;
}

export function KnowledgeBasePage({ user }: KnowledgeBasePageProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const knowledgeCategories = [
    {
      id: 'gst-basics',
      title: 'GST Basics',
      icon: '📚',
      articles: [
        { title: 'What is GST?', preview: 'Understand the basics of Goods and Services Tax in India' },
        { title: 'GST Registration Process', preview: 'Step-by-step guide to register for GST' },
        { title: 'GST Rates & Slabs', preview: 'Current GST rates for different categories' },
        { title: 'Input Tax Credit (ITC)', preview: 'How to claim and utilize input tax credit' },
      ],
    },
    {
      id: 'gst-filing',
      title: 'GST Filing & Returns',
      icon: '📝',
      articles: [
        { title: 'GSTR-1 Filing Guide', preview: 'How to file your monthly/quarterly sales returns' },
        { title: 'GSTR-3B Explained', preview: 'Understanding and filing GSTR-3B summary returns' },
        { title: 'GSTR-9 Annual Return', preview: 'Complete guide to annual GST returns' },
        { title: 'Filing Deadlines & Penalties', preview: 'Important dates and late filing penalties' },
      ],
    },
    {
      id: 'income-tax',
      title: 'Income Tax',
      icon: '💰',
      articles: [
        { title: 'Income Tax Slabs 2024-25', preview: 'Current tax rates for different income brackets' },
        { title: 'How to File ITR', preview: 'Step-by-step guide to file income tax returns' },
        { title: 'Tax Deductions & Exemptions', preview: 'Save tax under Section 80C, 80D, and more' },
        { title: 'TDS & Advance Tax', preview: 'Understanding tax deducted at source and advance tax' },
      ],
    },
    {
      id: 'business-tax',
      title: 'Business & Corporate Tax',
      icon: '🏢',
      articles: [
        { title: 'Startup Tax Benefits', preview: 'Tax exemptions and benefits for startups under Section 80-IAC' },
        { title: 'Corporate Tax Rates', preview: 'Tax rates for companies and corporations' },
        { title: 'Business Expenses & Deductions', preview: 'Allowable business expenses for tax deduction' },
        { title: 'Transfer Pricing', preview: 'Understanding transfer pricing regulations' },
      ],
    },
    {
      id: 'compliance',
      title: 'Compliance & Regulations',
      icon: '⚖️',
      articles: [
        { title: 'PAN & Aadhaar Linking', preview: 'How to link your PAN with Aadhaar' },
        { title: 'GST Audit Requirements', preview: 'Who needs to get GST audit done' },
        { title: 'Record Keeping Requirements', preview: 'What documents to maintain for tax compliance' },
        { title: 'E-invoicing Guidelines', preview: 'Understanding e-invoice requirements' },
      ],
    },
    {
      id: 'special-cases',
      title: 'Special Cases',
      icon: '⭐',
      articles: [
        { title: 'Reverse Charge Mechanism', preview: 'When buyer pays GST instead of seller' },
        { title: 'Composition Scheme', preview: 'Simplified tax scheme for small businesses' },
        { title: 'Export & Import Taxation', preview: 'Tax implications for international trade' },
        { title: 'E-commerce Taxation', preview: 'GST rules for e-commerce sellers' },
      ],
    },
  ];

  const filteredCategories = knowledgeCategories
    .map(category => ({
      ...category,
      articles: category.articles.filter(article =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.preview.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    }))
    .filter(category => category.articles.length > 0 || searchQuery === '');

  return (
    <div className="h-full p-8 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-3xl text-gray-800">Knowledge Base</h2>
              <p className="text-gray-600">Your comprehensive guide to tax and GST</p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search articles, guides, and documentation..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 py-6 text-lg"
            />
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white"
          >
            <FileText className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">24</p>
            <p className="text-blue-100">Total Articles</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white"
          >
            <BookOpen className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">6</p>
            <p className="text-purple-100">Categories</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl p-6 text-white"
          >
            <Download className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">12</p>
            <p className="text-pink-100">Downloads</p>
          </motion.div>
        </div>

        {/* Knowledge Categories */}
        <div className="space-y-6">
          {filteredCategories.map((category, idx) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200"
            >
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 px-6 py-4 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{category.icon}</span>
                  <h3 className="text-xl text-gray-800">{category.title}</h3>
                  <span className="ml-auto text-sm text-gray-500 bg-white px-3 py-1 rounded-full">
                    {category.articles.length} articles
                  </span>
                </div>
              </div>

              <Accordion type="single" collapsible className="w-full">
                {category.articles.map((article, articleIdx) => (
                  <AccordionItem key={`${category.id}-${articleIdx}`} value={`item-${articleIdx}`}>
                    <AccordionTrigger className="px-6 hover:bg-gray-50">
                      <div className="flex items-center gap-3 text-left">
                        <ChevronRight className="w-4 h-4 text-blue-500" />
                        <div>
                          <p className="text-gray-800">{article.title}</p>
                          <p className="text-sm text-gray-500 mt-1">{article.preview}</p>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6">
                      <div className="pl-7 pt-4 space-y-4">
                        <p className="text-gray-700">
                          This is a comprehensive guide about {article.title.toLowerCase()}. 
                          The content would include detailed explanations, examples, and step-by-step instructions.
                        </p>
                        <div className="flex gap-3">
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                          >
                            <FileText className="w-4 h-4" />
                            Read Full Article
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                          >
                            <Download className="w-4 h-4" />
                            Download PDF
                          </Button>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </motion.div>
          ))}
        </div>

        {/* No Results */}
        {filteredCategories.length === 0 && searchQuery && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">No articles found matching "{searchQuery}"</p>
            <p className="text-gray-500 mt-2">Try searching with different keywords</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
