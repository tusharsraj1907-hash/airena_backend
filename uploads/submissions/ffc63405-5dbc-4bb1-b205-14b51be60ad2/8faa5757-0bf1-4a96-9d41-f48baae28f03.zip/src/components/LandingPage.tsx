import { motion } from "motion/react";
import {
  Sparkles,
  Phone,
  Shield,
  Zap,
  BookOpen,
} from "lucide-react";
import { Button } from "./ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({
  onGetStarted,
}: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-indigo-900 to-purple-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-20 left-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.3, 0.5, 0.3],
            x: [0, -50, 0],
            y: [0, -30, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        {/* Floating particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={`particle-${i}`}
            className="absolute w-2 h-2 bg-white/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        {/* Logo/Brand */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center mb-12"
        >
          <motion.div
            className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full mb-6 shadow-2xl relative"
            animate={{
              boxShadow: [
                "0 0 20px rgba(139, 92, 246, 0.5)",
                "0 0 60px rgba(139, 92, 246, 0.8)",
                "0 0 20px rgba(139, 92, 246, 0.5)",
              ],
              rotate: [0, 5, -5, 0],
            }}
            transition={{
              boxShadow: {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              },
              rotate: {
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              },
            }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear",
              }}
            >
              <Sparkles className="w-12 h-12 text-white" />
            </motion.div>

            {/* Orbiting particles */}
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={`orbit-${i}`}
                className="absolute w-3 h-3 bg-white rounded-full"
                style={{
                  left: "50%",
                  top: "50%",
                }}
                animate={{
                  rotate: 360,
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear",
                  delay: i * 1,
                }}
              >
                <div
                  className="w-3 h-3 bg-gradient-to-r from-blue-300 to-purple-300 rounded-full"
                  style={{
                    transform: `translate(-50%, -50%) translateX(50px)`,
                  }}
                />
              </motion.div>
            ))}
          </motion.div>

          <motion.h1
            className="text-7xl mb-4 bg-gradient-to-r from-blue-200 via-purple-200 to-pink-200 bg-clip-text text-transparent"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              delay: 0.5,
              duration: 1,
              type: "spring",
            }}
          >
            BRUNO
          </motion.h1>

          <motion.p
            className="text-xl text-blue-100 mb-2"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7, duration: 1 }}
          >
            Your AI Tax & GST Assistant
          </motion.p>

          <motion.p
            className="text-blue-200/80 max-w-2xl mx-auto"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.9, duration: 1 }}
          >
            Get instant answers to all your tax and GST queries
            through intelligent voice conversations
          </motion.p>
        </motion.div>

        {/* Features */}
        <TooltipProvider delayDuration={0}>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12 max-w-5xl w-full"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1, duration: 0.8 }}
          >
            {[
              {
                icon: Phone,
                title: "Voice Enabled",
                desc: "Speak naturally with Bruno and get instant answers to your tax questions. Our advanced voice recognition technology understands your queries in real-time, making tax assistance as easy as having a conversation.",
                color: "from-blue-400 to-blue-600",
                delay: 0,
              },
              {
                icon: Shield,
                title: "Secure & Private",
                desc: "Your data is protected with enterprise-grade encryption. We follow strict privacy protocols and never share your personal information. All conversations are completely confidential and stored securely.",
                color: "from-purple-400 to-purple-600",
                delay: 0.1,
              },
              {
                icon: Zap,
                title: "Instant Answers",
                desc: "Get accurate, up-to-date tax information in seconds. Bruno is powered by the latest tax regulations and GST guidelines, ensuring you always receive reliable and current information for your queries.",
                color: "from-pink-400 to-pink-600",
                delay: 0.2,
              },
              {
                icon: BookOpen,
                title: "Knowledge Base",
                desc: "Access our comprehensive library of tax documentation, guides, and resources. From GST basics to complex compliance regulations, find detailed articles covering all aspects of taxation.",
                color: "from-emerald-400 to-emerald-600",
                delay: 0.3,
              },
            ].map((feature, idx) => (
              <Tooltip key={`feature-${idx}`}>
                <TooltipTrigger asChild>
                  <motion.div
                    className="flex flex-col items-center text-center cursor-pointer group"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.1 + feature.delay }}
                    whileHover={{ y: -12 }}
                  >
                    <motion.div
                      className={`w-20 h-20 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-3 shadow-2xl relative`}
                      animate={{ 
                        y: [0, -8, 0],
                        boxShadow: [
                          "0 10px 30px rgba(0, 0, 0, 0.3)",
                          "0 20px 50px rgba(0, 0, 0, 0.4)",
                          "0 10px 30px rgba(0, 0, 0, 0.3)"
                        ]
                      }}
                      transition={{
                        duration: 2.5,
                        repeat: Infinity,
                        delay: idx * 0.2,
                        ease: "easeInOut"
                      }}
                      whileHover={{
                        scale: 1.15,
                        rotate: [0, -5, 5, 0],
                        transition: { duration: 0.3 }
                      }}
                    >
                      <feature.icon className="w-10 h-10 text-white" />
                    </motion.div>
                    <h3 className="text-white text-lg group-hover:text-blue-200 transition-colors">
                      {feature.title}
                    </h3>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent 
                  className="max-w-xs bg-gradient-to-br from-blue-900 to-purple-900 border-white/20 text-white p-4 shadow-2xl"
                  side="bottom"
                  sideOffset={10}
                >
                  <p className="text-sm leading-relaxed">{feature.desc}</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </motion.div>
        </TooltipProvider>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{
            delay: 1.3,
            duration: 0.5,
            type: "spring",
          }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            onClick={onGetStarted}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-12 py-6 text-xl rounded-full shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 relative overflow-hidden group"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
              animate={{ x: ["-100%", "100%"] }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1,
              }}
            />
            <span className="relative z-10">Get Started</span>
            <motion.span
              className="ml-2 inline-block relative z-10"
              animate={{ x: [0, 5, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              →
            </motion.span>
          </Button>
        </motion.div>

        {/* Footer */}
        <motion.p
          className="text-blue-300/60 mt-16"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          Powered By{' '}
          <motion.a
            href="https://www.sashai.tech/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-300 hover:text-blue-200 transition-colors underline decoration-dotted underline-offset-4"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            SashAi
          </motion.a>
        </motion.p>
      </div>
    </div>
  );
}