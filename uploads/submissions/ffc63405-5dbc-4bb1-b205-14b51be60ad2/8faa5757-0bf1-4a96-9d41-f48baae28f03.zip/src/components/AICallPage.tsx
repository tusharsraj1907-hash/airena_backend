import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, PhoneOff, Upload, Coins, CreditCard, Smartphone, FileSpreadsheet, X, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { PaymentModal } from './PaymentModal';

interface AICallPageProps {
  user: any;
}

export function AICallPage({ user }: AICallPageProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isCalling, setIsCalling] = useState(false);
  const [callStatus, setCallStatus] = useState<'idle' | 'connecting' | 'active' | 'ended'>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [credits, setCredits] = useState(150); // Mock credits
  const [showRechargeDialog, setShowRechargeDialog] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<{ amount: number; credits: number } | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [bulkCalls, setBulkCalls] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleStartCall = () => {
    if (!phoneNumber || credits < 10) return;
    
    setIsCalling(true);
    setCallStatus('connecting');
    setCredits(prev => prev - 10); // Deduct 10 credits per call
    
    // Simulate call connection
    setTimeout(() => {
      setCallStatus('active');
      // Start call timer
      const timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
      
      // Store timer ID to clear later
      (window as any).callTimer = timer;
    }, 2000);
  };

  const handleEndCall = () => {
    setIsCalling(false);
    setCallStatus('ended');
    
    // Clear timer
    if ((window as any).callTimer) {
      clearInterval((window as any).callTimer);
    }
    
    // Reset after 3 seconds
    setTimeout(() => {
      setCallStatus('idle');
      setCallDuration(0);
      setPhoneNumber('');
    }, 3000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      // Mock parsing Excel file
      const mockData = [
        { name: 'John Doe', phone: '+1 (555) 111-2222', status: 'pending' },
        { name: 'Jane Smith', phone: '+1 (555) 333-4444', status: 'pending' },
        { name: 'Bob Johnson', phone: '+1 (555) 555-6666', status: 'pending' },
        { name: 'Alice Williams', phone: '+1 (555) 777-8888', status: 'pending' },
      ];
      setBulkCalls(mockData);
    }
  };

  const handleBulkCall = () => {
    if (credits < bulkCalls.length * 10) {
      alert('Insufficient credits for bulk calls!');
      return;
    }
    
    setCredits(prev => prev - (bulkCalls.length * 10));
    
    // Simulate bulk calling
    alert(`Initiating ${bulkCalls.length} calls...`);
    setBulkCalls([]);
    setUploadedFile(null);
    setShowBulkUpload(false);
  };

  const handleRecharge = (amount: number, credits: number) => {
    // In real app, this would integrate with payment gateway
    alert(`Processing payment of ₹${amount}...`);
    setCredits(prev => prev + credits);
    setShowRechargeDialog(false);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const rechargePackages = [
    { amount: 99, credits: 50, popular: false },
    { amount: 199, credits: 120, popular: true },
    { amount: 499, credits: 350, popular: false },
    { amount: 999, credits: 800, popular: false },
  ];

  return (
    <div className="h-full p-8 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* Header with Credits */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl text-gray-800 mb-2">AI Call</h2>
            <p className="text-gray-600">Bruno will call and provide tax assistance</p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Credits Display */}
            <motion.div 
              className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-full flex items-center gap-3 shadow-lg"
              whileHover={{ scale: 1.05 }}
            >
              <Coins className="w-5 h-5" />
              <div>
                <p className="text-xs opacity-90">Available Credits</p>
                <p className="text-xl">{credits}</p>
              </div>
            </motion.div>
            
            <Button
              onClick={() => setShowRechargeDialog(true)}
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              Recharge
            </Button>
          </div>
        </div>

        {/* Call Type Tabs */}
        <Tabs defaultValue="single" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="single">Single Call</TabsTrigger>
            <TabsTrigger value="bulk">Bulk Calls</TabsTrigger>
          </TabsList>

          {/* Single Call */}
          <TabsContent value="single">
            <div className="flex flex-col items-center justify-center max-w-md mx-auto">
              {callStatus === 'idle' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="w-full space-y-6"
                >
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-2">Cost: 10 credits per call</p>
                  </div>

                  <Button
                    onClick={handleStartCall}
                    disabled={!phoneNumber || credits < 10}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white py-6"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    Start AI Call
                  </Button>
                  
                  {credits < 10 && (
                    <p className="text-sm text-red-500 text-center">
                      Insufficient credits. Please recharge to continue.
                    </p>
                  )}
                </motion.div>
              )}

              {callStatus !== 'idle' && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center w-full"
                >
                  {/* Phone animation */}
                  <div className="relative mb-8">
                    <motion.div
                      className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center ${
                        callStatus === 'active'
                          ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                          : callStatus === 'connecting'
                          ? 'bg-gradient-to-br from-blue-500 to-indigo-600'
                          : 'bg-gradient-to-br from-gray-500 to-gray-600'
                      }`}
                      animate={callStatus === 'active' ? {
                        scale: [1, 1.05, 1],
                      } : {}}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                      }}
                    >
                      <Phone className="w-16 h-16 text-white" />
                    </motion.div>

                    {/* Call rings animation */}
                    {(callStatus === 'connecting' || callStatus === 'active') && (
                      <>
                        {[...Array(3)].map((_, i) => (
                          <motion.div
                            key={`call-ring-${i}`}
                            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-4 border-green-400"
                            initial={{ scale: 1, opacity: 0.8 }}
                            animate={{
                              scale: [1, 1.5, 2],
                              opacity: [0.8, 0.4, 0],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                              delay: i * 0.4,
                            }}
                          />
                        ))}
                      </>
                    )}
                  </div>

                  <div className="mb-6">
                    <p className="text-2xl mb-2 text-gray-800">{phoneNumber}</p>
                    <p className="text-gray-600">
                      {callStatus === 'connecting' && 'Connecting...'}
                      {callStatus === 'active' && 'Call in progress'}
                      {callStatus === 'ended' && 'Call ended'}
                    </p>
                    {callStatus === 'active' && (
                      <p className="text-3xl mt-4 text-gray-800">{formatDuration(callDuration)}</p>
                    )}
                  </div>

                  {callStatus !== 'ended' && (
                    <Button
                      onClick={handleEndCall}
                      className="bg-red-500 hover:bg-red-600 text-white px-12 py-6 rounded-full"
                    >
                      <PhoneOff className="w-6 h-6 mr-2" />
                      End Call
                    </Button>
                  )}
                </motion.div>
              )}
            </div>
          </TabsContent>

          {/* Bulk Calls */}
          <TabsContent value="bulk">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-2xl mx-auto"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="text-center mb-6">
                  <FileSpreadsheet className="w-16 h-16 text-blue-500 mx-auto mb-4" />
                  <h3 className="text-2xl text-gray-800 mb-2">Upload Excel File for Bulk Calls</h3>
                  <p className="text-gray-600">Upload a file with phone numbers to make multiple calls at once</p>
                  <p className="text-sm text-gray-500 mt-2">Format: Name, Phone Number (one per row)</p>
                </div>

                <div className="space-y-6">
                  {!uploadedFile ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all"
                    >
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-2">Click to upload Excel file</p>
                      <p className="text-sm text-gray-500">.xlsx, .xls, .csv supported</p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".xlsx,.xls,.csv"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* File Info */}
                      <div className="flex items-center justify-between bg-blue-50 rounded-lg p-4">
                        <div className="flex items-center gap-3">
                          <FileSpreadsheet className="w-8 h-8 text-blue-500" />
                          <div>
                            <p className="text-gray-800">{uploadedFile.name}</p>
                            <p className="text-sm text-gray-500">{bulkCalls.length} contacts found</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setUploadedFile(null);
                            setBulkCalls([]);
                          }}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>

                      {/* Preview */}
                      <div className="border rounded-lg overflow-hidden">
                        <div className="bg-gray-50 px-4 py-2 border-b">
                          <p className="text-sm text-gray-700">Preview</p>
                        </div>
                        <div className="max-h-48 overflow-auto">
                          {bulkCalls.map((call, idx) => (
                            <div key={idx} className="px-4 py-3 border-b hover:bg-gray-50 flex items-center justify-between">
                              <div>
                                <p className="text-gray-800">{call.name}</p>
                                <p className="text-sm text-gray-500">{call.phone}</p>
                              </div>
                              <Badge variant="outline">Pending</Badge>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Cost Info */}
                      <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">Total Calls:</span>
                          <span className="text-gray-800">{bulkCalls.length}</span>
                        </div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">Cost per Call:</span>
                          <span className="text-gray-800">10 credits</span>
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t border-amber-300">
                          <span className="text-gray-800">Total Cost:</span>
                          <span className="text-lg text-amber-700">{bulkCalls.length * 10} credits</span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => {
                            setUploadedFile(null);
                            setBulkCalls([]);
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                          onClick={handleBulkCall}
                          disabled={credits < bulkCalls.length * 10}
                        >
                          <Phone className="w-4 h-4 mr-2" />
                          Start Bulk Calls
                        </Button>
                      </div>

                      {credits < bulkCalls.length * 10 && (
                        <p className="text-sm text-red-500 text-center">
                          Insufficient credits. Need {bulkCalls.length * 10 - credits} more credits.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>

        {/* Recharge Dialog */}
        <Dialog open={showRechargeDialog} onOpenChange={setShowRechargeDialog}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Recharge Credits</DialogTitle>
              <DialogDescription>
                Choose a package to add credits to your account
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {rechargePackages.map((pkg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className={`relative border-2 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all ${
                    pkg.popular
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  {pkg.popular && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-500">
                      Most Popular
                    </Badge>
                  )}
                  
                  <div className="text-center mb-4">
                    <p className="text-3xl text-gray-800 mb-2">₹{pkg.amount}</p>
                    <div className="flex items-center justify-center gap-2 text-amber-600">
                      <Coins className="w-5 h-5" />
                      <p className="text-xl">{pkg.credits} Credits</p>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      ₹{(pkg.amount / pkg.credits).toFixed(2)} per credit
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Button
                      onClick={() => {
                        setSelectedPackage(pkg);
                        setShowPaymentModal(true);
                      }}
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white gap-2"
                    >
                      <CreditCard className="w-4 h-4" />
                      Pay via UPI/Card
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">Accepted Payment Methods:</p>
              <div className="flex gap-4 items-center">
                <Badge variant="outline" className="gap-2">
                  <Smartphone className="w-3 h-3" />
                  UPI
                </Badge>
                <Badge variant="outline" className="gap-2">
                  <CreditCard className="w-3 h-3" />
                  Credit/Debit Card
                </Badge>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Payment Modal */}
        {selectedPackage && (
          <PaymentModal
            isOpen={showPaymentModal}
            onClose={() => {
              setShowPaymentModal(false);
              setShowRechargeDialog(false);
            }}
            packageAmount={selectedPackage.amount}
            packageCredits={selectedPackage.credits}
            onPaymentSuccess={(credits) => {
              setCredits(prev => prev + credits);
            }}
          />
        )}
      </div>
    </div>
  );
}