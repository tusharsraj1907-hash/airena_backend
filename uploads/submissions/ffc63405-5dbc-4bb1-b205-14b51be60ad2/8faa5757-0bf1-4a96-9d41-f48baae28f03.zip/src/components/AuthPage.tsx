import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Mail, Lock, User, Phone, Shield, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface AuthPageProps {
  mode: 'signin' | 'signup' | 'forgot';
  onAuthSuccess: (user: any) => void;
  onSwitchMode: (mode: 'signin' | 'signup' | 'forgot') => void;
}

export function AuthPage({ mode, onAuthSuccess, onSwitchMode }: AuthPageProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>(mode === 'signup' ? 'signup' : 'signin');
  const [showForgotPassword, setShowForgotPassword] = useState(mode === 'forgot');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [adminClickCount, setAdminClickCount] = useState(0);
  const [showAdminField, setShowAdminField] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (showForgotPassword) {
      alert('Password reset link sent to your email!');
      setShowForgotPassword(false);
      setActiveTab('signin');
      return;
    }

    const user = {
      id: '1',
      name: formData.name || 'User',
      email: formData.email,
      phone: formData.phone,
      role: showAdminField || formData.email.includes('admin') ? 'admin' : 'user'
    };

    onAuthSuccess(user);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSecretClick = () => {
    const newCount = adminClickCount + 1;
    setAdminClickCount(newCount);
    
    if (newCount >= 4) {
      setShowAdminField(true);
    }
  };

  const handleTabSwitch = (tab: 'signin' | 'signup') => {
    setActiveTab(tab);
    setShowForgotPassword(false);
    setShowAdminField(false);
    setAdminClickCount(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-indigo-900 to-purple-900 relative overflow-hidden flex items-center justify-center px-4">
      {/* Animated background */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
        }}
      />
      
      <motion.div
        className="absolute bottom-20 right-10 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
        }}
      />

      {/* Floating particles */}
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={`auth-particle-${i}`}
          className="absolute w-1 h-1 bg-white/40 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -50, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 2 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 3,
          }}
        />
      ))}

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-5xl">
        <div className="relative h-[600px] overflow-hidden">
          {/* Sliding Container */}
          <div className="relative h-full flex items-center justify-center">
            {/* Sign In Form */}
            <motion.div
              initial={false}
              animate={{
                x: activeTab === 'signin' ? '0%' : '-100%',
                opacity: activeTab === 'signin' ? 1 : 0,
              }}
              transition={{
                type: 'spring',
                stiffness: 300,
                damping: 30,
              }}
              className="absolute w-full max-w-md"
            >
              <motion.div 
                className="bg-white/10 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl relative overflow-hidden"
                whileHover={{ boxShadow: "0 0 40px rgba(139, 92, 246, 0.3)" }}
              >
                {/* Animated border glow */}
                <motion.div
                  className="absolute inset-0 rounded-2xl"
                  style={{
                    background: 'linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.5), transparent)',
                  }}
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                />
                
                {/* Header */}
                <div className="text-center mb-8 relative z-10">
                  <motion.div 
                    className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full mb-4"
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Sparkles className="w-8 h-8 text-white" />
                  </motion.div>
                  <h2 className="text-3xl text-white mb-2">Welcome Back</h2>
                  <p className="text-blue-200/80">Sign in to continue to Bruno</p>
                </div>

                {/* Sign In Form */}
                <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                  <div>
                    <Label htmlFor="signin-email" className="text-white">Email Address</Label>
                    <div className="relative mt-1">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signin-email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your email"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="signin-password" className="text-white">Password</Label>
                    <div className="relative mt-1">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signin-password"
                        name="password"
                        type="password"
                        required
                        value={formData.password}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your password"
                      />
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <motion.button
                      type="button"
                      onClick={() => setShowForgotPassword(true)}
                      className="text-blue-300 hover:text-blue-200 transition-colors text-sm"
                      whileHover={{ x: 5 }}
                    >
                      Forgot Password?
                    </motion.button>
                    
                    {/* Secret Admin Button */}
                    <motion.button
                      type="button"
                      onClick={handleSecretClick}
                      className="w-2 h-2 rounded-full bg-white/5 hover:bg-white/10 transition-all"
                      animate={adminClickCount > 0 ? {
                        scale: [1, 1.5, 1],
                        backgroundColor: [
                          'rgba(255, 255, 255, 0.05)',
                          `rgba(139, 92, 246, ${Math.min(adminClickCount * 0.25, 1)})`,
                          'rgba(255, 255, 255, 0.05)',
                        ]
                      } : {}}
                      transition={{ duration: 0.3 }}
                    />
                  </div>

                  {/* Admin Access Field */}
                  <AnimatePresence>
                    {showAdminField && (
                      <motion.div
                        initial={{ opacity: 0, height: 0, scale: 0.8 }}
                        animate={{ opacity: 1, height: 'auto', scale: 1 }}
                        exit={{ opacity: 0, height: 0, scale: 0.8 }}
                        className="border border-purple-500/50 rounded-lg p-4 bg-purple-500/10"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <motion.div
                            animate={{ rotate: [0, 360] }}
                            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                          >
                            <Shield className="w-5 h-5 text-purple-300" />
                          </motion.div>
                          <Label className="text-purple-200">Admin Access Unlocked</Label>
                        </div>
                        <p className="text-xs text-purple-300 mb-2">
                          You will be logged in with administrator privileges
                        </p>
                        <motion.div
                          className="flex items-center gap-2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.3 }}
                        >
                          {[...Array(4)].map((_, i) => (
                            <motion.div
                              key={`admin-bar-${i}`}
                              className="h-2 flex-1 rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                              initial={{ width: 0 }}
                              animate={{ width: '100%' }}
                              transition={{ delay: i * 0.1 }}
                            />
                          ))}
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-6 relative overflow-hidden"
                    >
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                        animate={{ x: ['-100%', '100%'] }}
                        transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                      />
                      <span className="relative z-10">
                        {showAdminField ? 'Sign In as Admin' : 'Sign In'}
                      </span>
                    </Button>
                  </motion.div>

                  <div className="text-center">
                    <p className="text-blue-200">
                      Don't have an account?{' '}
                      <motion.button
                        type="button"
                        onClick={() => handleTabSwitch('signup')}
                        className="text-blue-300 hover:text-blue-200"
                        whileHover={{ scale: 1.05 }}
                      >
                        Sign Up
                      </motion.button>
                    </p>
                  </div>
                </form>
              </motion.div>
            </motion.div>

            {/* Sign Up Form */}
            <motion.div
              initial={false}
              animate={{
                x: activeTab === 'signup' ? '0%' : '100%',
                opacity: activeTab === 'signup' ? 1 : 0,
              }}
              transition={{
                type: 'spring',
                stiffness: 300,
                damping: 30,
              }}
              className="absolute w-full max-w-md"
            >
              <motion.div 
                className="bg-white/10 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl relative overflow-hidden"
                whileHover={{ boxShadow: "0 0 40px rgba(139, 92, 246, 0.3)" }}
              >
                {/* Animated border glow */}
                <motion.div
                  className="absolute inset-0 rounded-2xl"
                  style={{
                    background: 'linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.5), transparent)',
                  }}
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                />
                
                {/* Header */}
                <div className="text-center mb-8 relative z-10">
                  <motion.div 
                    className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full mb-4"
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Sparkles className="w-8 h-8 text-white" />
                  </motion.div>
                  <h2 className="text-3xl text-white mb-2">Create Account</h2>
                  <p className="text-blue-200/80">Join Bruno for AI-powered tax assistance</p>
                </div>

                {/* Sign Up Form */}
                <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                  <div>
                    <Label htmlFor="signup-name" className="text-white">Full Name</Label>
                    <div className="relative mt-1">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signup-name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your full name"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="signup-email" className="text-white">Email Address</Label>
                    <div className="relative mt-1">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signup-email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your email"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="signup-phone" className="text-white">Phone Number</Label>
                    <div className="relative mt-1">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signup-phone"
                        name="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your phone number"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="signup-password" className="text-white">Password</Label>
                    <div className="relative mt-1">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signup-password"
                        name="password"
                        type="password"
                        required
                        value={formData.password}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Enter your password"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="signup-confirm" className="text-white">Confirm Password</Label>
                    <div className="relative mt-1">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                      <Input
                        id="signup-confirm"
                        name="confirmPassword"
                        type="password"
                        required
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        className="pl-11 bg-white/10 border-white/20 text-white placeholder:text-blue-200/50 focus:border-blue-400"
                        placeholder="Confirm your password"
                      />
                    </div>
                  </div>

                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-6 relative overflow-hidden"
                    >
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                        animate={{ x: ['-100%', '100%'] }}
                        transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                      />
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        Create Account
                        <ArrowRight className="w-5 h-5" />
                      </span>
                    </Button>
                  </motion.div>

                  <div className="text-center">
                    <p className="text-blue-200">
                      Already have an account?{' '}
                      <motion.button
                        type="button"
                        onClick={() => handleTabSwitch('signin')}
                        className="text-blue-300 hover:text-blue-200"
                        whileHover={{ scale: 1.05 }}
                      >
                        Sign In
                      </motion.button>
                    </p>
                  </div>
                </form>
              </motion.div>
            </motion.div>

            {/* Overlay Panel that slides */}
            <motion.div
              initial={false}
              animate={{
                x: activeTab === 'signin' ? '200%' : '-200%',
              }}
              transition={{
                type: 'spring',
                stiffness: 300,
                damping: 30,
              }}
              className="absolute w-full max-w-md h-full flex items-center justify-center pointer-events-none"
            >
              <div className="w-full h-[600px] bg-gradient-to-br from-blue-600/30 to-purple-600/30 backdrop-blur-sm rounded-2xl border border-white/30 shadow-2xl" />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
