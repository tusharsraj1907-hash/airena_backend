import { useState } from 'react';
import { Sidebar } from './Sidebar';
import { VoiceAssistant } from './VoiceAssistant';
import { ProfilePage } from './ProfilePage';
import { TranscriptPage } from './TranscriptPage';
import { AICallPage } from './AICallPage';
import { KnowledgeBasePage } from './KnowledgeBasePage';

interface DashboardProps {
  user: any;
  onLogout: () => void;
}

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'speak' | 'call' | 'transcript' | 'profile' | 'knowledge'>('speak');

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Sidebar
        user={user}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onLogout={onLogout}
      />
      
      <main className="flex-1 overflow-auto">
        {activeTab === 'speak' && <VoiceAssistant user={user} />}
        {activeTab === 'call' && <AICallPage user={user} />}
        {activeTab === 'transcript' && <TranscriptPage user={user} />}
        {activeTab === 'knowledge' && <KnowledgeBasePage user={user} />}
        {activeTab === 'profile' && <ProfilePage user={user} />}
      </main>
    </div>
  );
}