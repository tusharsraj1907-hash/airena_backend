import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Sparkles, Waves } from 'lucide-react';
import { Button } from './ui/button';

interface VoiceAssistantProps {
  user: any;
}

export function VoiceAssistant({ user }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [showStartButton, setShowStartButton] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleStartTalking = () => {
    setShowStartButton(false);
  };

  const handleToggleListening = () => {
    if (!isListening) {
      // Start listening
      setIsListening(true);
      setTranscript('');
      setAiResponse('');
      setIsSpeaking(false);
      
      // Simulate voice recognition
      setTimeout(() => {
        setIsSpeaking(true);
        setTranscript('What is the current GST rate for textile products?');
      }, 2000);
      
      setTimeout(() => {
        setIsSpeaking(false);
        setAiResponse('The current GST rate for textile products is 5% for fabrics and 12% for ready-made garments.');
      }, 4000);
    } else {
      // Stop listening
      setIsListening(false);
      setIsSpeaking(false);
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-8 relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div
        className="absolute top-20 left-20 w-64 h-64 bg-blue-200/20 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        className="absolute bottom-20 right-20 w-80 h-80 bg-purple-200/20 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <AnimatePresence mode="wait">
        {showStartButton ? (
          <motion.div
            key="start-screen"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="text-center relative z-10"
          >
            <motion.div
              className="w-32 h-32 mx-auto mb-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center shadow-2xl relative"
              animate={{
                boxShadow: [
                  "0 0 40px rgba(139, 92, 246, 0.5)",
                  "0 0 80px rgba(139, 92, 246, 0.8)",
                  "0 0 40px rgba(139, 92, 246, 0.5)"
                ]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              <motion.div
                animate={{ 
                  rotate: 360,
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                  scale: { duration: 2, repeat: Infinity, ease: "easeInOut" }
                }}
              >
                <Sparkles className="w-16 h-16 text-white" />
              </motion.div>
              
              {/* Pulsing rings */}
              {[0, 1, 2].map((index) => (
                <motion.div
                  key={`welcome-pulse-ring-${index}`}
                  className="absolute inset-0 rounded-full border-2 border-white/30"
                  animate={{
                    scale: [1, 1.5, 2],
                    opacity: [0.8, 0.4, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: index * 0.4,
                  }}
                />
              ))}
            </motion.div>
            
            <motion.h2 
              className="text-4xl mb-4 text-gray-800"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Welcome, {user?.name}!
            </motion.h2>
            <motion.p 
              className="text-xl text-gray-600 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Ready to speak with Bruno?
            </motion.p>
            
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                onClick={handleStartTalking}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-6 text-xl rounded-full relative overflow-hidden"
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                />
                <span className="relative z-10">Start Talking</span>
              </Button>
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            key="assistant-screen"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-4xl relative z-10"
          >
            {/* Voice Animation */}
            <div className="flex flex-col items-center mb-12">
              <div className="relative">
                {/* Main circle */}
                <motion.div
                  className={`w-48 h-48 rounded-full flex items-center justify-center relative ${
                    isListening
                      ? 'bg-gradient-to-br from-blue-500 to-purple-600'
                      : 'bg-gradient-to-br from-gray-400 to-gray-500'
                  }`}
                  animate={isListening ? {
                    scale: [1, 1.05, 1],
                    boxShadow: [
                      "0 0 30px rgba(59, 130, 246, 0.5)",
                      "0 0 60px rgba(139, 92, 246, 0.8)",
                      "0 0 30px rgba(59, 130, 246, 0.5)"
                    ]
                  } : {}}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                  }}
                >
                  <motion.div
                    animate={isListening ? { 
                      scale: [1, 1.05, 1],
                    } : {}}
                    transition={{ 
                      duration: 0.8,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    {isListening ? (
                      <Mic className="w-24 h-24 text-white" />
                    ) : (
                      <MicOff className="w-24 h-24 text-white" />
                    )}
                  </motion.div>

                  {/* Rotating sparkles */}
                  {isListening && [0, 1, 2, 3, 4, 5].map((index) => (
                    <motion.div
                      key={`voice-sparkle-${index}`}
                      className="absolute w-3 h-3 bg-white rounded-full"
                      style={{
                        left: '50%',
                        top: '50%',
                      }}
                      animate={{
                        rotate: 360,
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        ease: "linear",
                        delay: index * 0.5,
                      }}
                    >
                      <div
                        className="w-3 h-3 bg-gradient-to-r from-blue-300 to-purple-300 rounded-full blur-sm"
                        style={{
                          transform: `translate(-50%, -50%) translateX(${70 + index * 10}px)`,
                        }}
                      />
                    </motion.div>
                  ))}
                </motion.div>

                {/* Animated rings when listening */}
                {isListening && (
                  <>
                    {[0, 1, 2].map((index) => (
                      <motion.div
                        key={`active-listening-ring-${index}`}
                        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border-4 border-blue-400"
                        initial={{ scale: 1, opacity: 0.8 }}
                        animate={{
                          scale: [1, 1.5, 2],
                          opacity: [0.8, 0.4, 0],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: index * 0.4,
                        }}
                      />
                    ))}
                  </>
                )}

                {/* Sound wave animation */}
                {isSpeaking && (
                  <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 flex items-center gap-2">
                    {[0, 1, 2, 3, 4].map((index) => (
                      <motion.div
                        key={`audio-wave-bar-${index}`}
                        className="w-2 bg-gradient-to-t from-blue-500 to-purple-600 rounded-full"
                        animate={{
                          height: ["20px", "60px", "20px"],
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          delay: index * 0.1,
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Status text */}
              <motion.p
                className="mt-24 text-xl text-gray-700"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {isListening ? 'Listening...' : 'Click to speak with Bruno'}
              </motion.p>
            </div>

            {/* Control Button */}
            <div className="flex justify-center mb-8">
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  onClick={handleToggleListening}
                  className={`px-12 py-6 text-xl rounded-full relative overflow-hidden ${
                    isListening
                      ? 'bg-red-500 hover:bg-red-600'
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
                  } text-white`}
                >
                  {isListening && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                  )}
                  <span className="relative z-10">
                    {isListening ? 'Stop' : 'Start Speaking'}
                  </span>
                </Button>
              </motion.div>
            </div>

            {/* Transcript and Response */}
            <div className="space-y-4">
              <AnimatePresence>
                {transcript && (
                  <motion.div
                    key="user-transcript"
                    initial={{ opacity: 0, x: -20, scale: 0.95 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, x: -20, scale: 0.95 }}
                    className="bg-blue-100 rounded-2xl p-6 ml-12 relative overflow-hidden"
                  >
                    <motion.div
                      className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-blue-500 to-purple-600"
                      initial={{ height: 0 }}
                      animate={{ height: '100%' }}
                      transition={{ duration: 0.5 }}
                    />
                    <p className="text-gray-800">{transcript}</p>
                    <p className="text-xs text-gray-500 mt-2">You</p>
                  </motion.div>
                )}

                {aiResponse && (
                  <motion.div
                    key="bruno-response"
                    initial={{ opacity: 0, x: 20, scale: 0.95 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, x: 20, scale: 0.95 }}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 mr-12 text-white relative overflow-hidden"
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 3, repeat: Infinity, repeatDelay: 1 }}
                    />
                    <p className="relative z-10">{aiResponse}</p>
                    <p className="text-xs text-blue-100 mt-2 relative z-10">Bruno</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}