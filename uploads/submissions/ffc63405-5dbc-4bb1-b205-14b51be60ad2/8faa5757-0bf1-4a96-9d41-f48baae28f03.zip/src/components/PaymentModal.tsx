import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  CreditCard, 
  Smartphone, 
  CheckCircle,
  Coins,
  ArrowRight,
  Building2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  packageAmount: number;
  packageCredits: number;
  onPaymentSuccess: (credits: number) => void;
}

export function PaymentModal({
  isOpen,
  onClose,
  packageAmount,
  packageCredits,
  onPaymentSuccess,
}: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card'>('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // UPI State
  const [selectedUpiApp, setSelectedUpiApp] = useState<string>('');
  const [upiId, setUpiId] = useState('');

  // Card State
  const [cardType, setCardType] = useState<'debit' | 'credit'>('debit');
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');
  const [cvv, setCvv] = useState('');

  const upiApps = [
    { id: 'gpay', name: 'Google Pay', icon: '🟢' },
    { id: 'phonepe', name: 'PhonePe', icon: '🟣' },
    { id: 'paytm', name: 'Paytm', icon: '🔵' },
    { id: 'bhim', name: 'BHIM UPI', icon: '🟠' },
  ];

  const handlePayment = () => {
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentSuccess(true);

      // Wait a bit to show success, then complete
      setTimeout(() => {
        onPaymentSuccess(packageCredits);
        handleClose();
      }, 2000);
    }, 2500);
  };

  const handleClose = () => {
    setPaymentSuccess(false);
    setIsProcessing(false);
    setUpiId('');
    setSelectedUpiApp('');
    setCardNumber('');
    setCardHolder('');
    setExpiryMonth('');
    setExpiryYear('');
    setCvv('');
    onClose();
  };

  const formatCardNumber = (value: string) => {
    const cleaned = value.replace(/\s/g, '');
    const chunks = cleaned.match(/.{1,4}/g);
    return chunks ? chunks.join(' ') : cleaned;
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\s/g, '');
    if (value.length <= 16 && /^\d*$/.test(value)) {
      setCardNumber(value);
    }
  };

  const isUpiValid = selectedUpiApp ? true : upiId.includes('@');
  const isCardValid = cardNumber.length === 16 && cardHolder && expiryMonth && expiryYear && cvv.length === 3;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Complete Payment</DialogTitle>
          <DialogDescription>
            Pay ₹{packageAmount} to get {packageCredits} credits
          </DialogDescription>
        </DialogHeader>

        {!paymentSuccess ? (
          <div className="space-y-6 mt-4">
            {/* Package Summary */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 border border-blue-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-white rounded-full p-3">
                    <Coins className="w-6 h-6 text-amber-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">You're buying</p>
                    <p className="text-xl text-gray-800">{packageCredits} Credits</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600">Total Amount</p>
                  <p className="text-2xl text-gray-800">₹{packageAmount}</p>
                </div>
              </div>
            </div>

            {/* Payment Method Tabs */}
            <div className="relative bg-gray-100 rounded-xl p-1">
              {/* Sliding background */}
              <motion.div
                className="absolute top-1 bottom-1 left-1 bg-white rounded-lg shadow-md"
                initial={false}
                animate={{
                  x: paymentMethod === 'upi' ? '0%' : '100%',
                }}
                transition={{
                  type: 'spring',
                  stiffness: 300,
                  damping: 30,
                }}
                style={{
                  width: 'calc(50% - 4px)',
                }}
              />
              
              {/* Tab buttons */}
              <div className="relative flex">
                <button
                  onClick={() => setPaymentMethod('upi')}
                  className={`flex-1 py-3 flex items-center justify-center gap-2 transition-colors duration-300 rounded-lg relative z-10 ${
                    paymentMethod === 'upi' ? 'text-blue-600' : 'text-gray-600'
                  }`}
                >
                  <Smartphone className="w-5 h-5" />
                  UPI
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`flex-1 py-3 flex items-center justify-center gap-2 transition-colors duration-300 rounded-lg relative z-10 ${
                    paymentMethod === 'card' ? 'text-blue-600' : 'text-gray-600'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  Debit/Credit Card
                </button>
              </div>
            </div>

            {/* Payment Forms */}
            <motion.div
              key={paymentMethod}
              initial={{ opacity: 0, x: paymentMethod === 'upi' ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              {paymentMethod === 'upi' ? (
                <div className="space-y-4">
                  {/* UPI Apps */}
                  <div>
                    <Label className="mb-3 block">Select UPI App</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {upiApps.map((app) => (
                        <motion.button
                          key={app.id}
                          type="button"
                          onClick={() => {
                            setSelectedUpiApp(app.id);
                            setUpiId('');
                          }}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            selectedUpiApp === app.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{app.icon}</span>
                            <span className="text-gray-800">{app.name}</span>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* OR Divider */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-300" />
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-white text-gray-500">OR</span>
                    </div>
                  </div>

                  {/* UPI ID Input */}
                  <div>
                    <Label htmlFor="upiId">Enter UPI ID</Label>
                    <Input
                      id="upiId"
                      type="text"
                      placeholder="yourname@upi"
                      value={upiId}
                      onChange={(e) => {
                        setUpiId(e.target.value);
                        setSelectedUpiApp('');
                      }}
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Enter your UPI ID (e.g., 9876543210@paytm)
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Card Type Selection */}
                  <div>
                    <Label className="mb-3 block">Card Type</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <motion.button
                        type="button"
                        onClick={() => setCardType('debit')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          cardType === 'debit'
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="flex items-center gap-2">
                          <Building2 className="w-5 h-5 text-gray-600" />
                          <span className="text-gray-800">Debit Card</span>
                        </div>
                      </motion.button>
                      <motion.button
                        type="button"
                        onClick={() => setCardType('credit')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          cardType === 'credit'
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-5 h-5 text-gray-600" />
                          <span className="text-gray-800">Credit Card</span>
                        </div>
                      </motion.button>
                    </div>
                  </div>

                  {/* Card Number */}
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      value={formatCardNumber(cardNumber)}
                      onChange={handleCardNumberChange}
                      className="mt-1"
                      maxLength={19}
                    />
                  </div>

                  {/* Card Holder Name */}
                  <div>
                    <Label htmlFor="cardHolder">Card Holder Name</Label>
                    <Input
                      id="cardHolder"
                      type="text"
                      placeholder="John Doe"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                      className="mt-1"
                    />
                  </div>

                  {/* Expiry and CVV */}
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label htmlFor="expiryMonth">Month</Label>
                      <Input
                        id="expiryMonth"
                        type="text"
                        placeholder="MM"
                        value={expiryMonth}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val.length <= 2 && /^\d*$/.test(val) && (val === '' || parseInt(val) <= 12)) {
                            setExpiryMonth(val);
                          }
                        }}
                        className="mt-1"
                        maxLength={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="expiryYear">Year</Label>
                      <Input
                        id="expiryYear"
                        type="text"
                        placeholder="YY"
                        value={expiryYear}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val.length <= 2 && /^\d*$/.test(val)) {
                            setExpiryYear(val);
                          }
                        }}
                        className="mt-1"
                        maxLength={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        type="password"
                        placeholder="123"
                        value={cvv}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val.length <= 3 && /^\d*$/.test(val)) {
                            setCvv(val);
                          }
                        }}
                        className="mt-1"
                        maxLength={3}
                      />
                    </div>
                  </div>
                </div>
              )}
            </motion.div>

            {/* Payment Button */}
            <div className="pt-4 border-t">
              <Button
                onClick={handlePayment}
                disabled={isProcessing || (paymentMethod === 'upi' ? !isUpiValid : !isCardValid)}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white py-6 text-lg relative overflow-hidden"
              >
                {isProcessing ? (
                  <>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    />
                    <span className="relative z-10">Processing Payment...</span>
                  </>
                ) : (
                  <>
                    <span>Pay ₹{packageAmount}</span>
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
              
              {paymentMethod === 'upi' && !isUpiValid && (
                <p className="text-sm text-red-500 mt-2 text-center">
                  Please select a UPI app or enter a valid UPI ID
                </p>
              )}
              {paymentMethod === 'card' && !isCardValid && (
                <p className="text-sm text-red-500 mt-2 text-center">
                  Please fill in all card details correctly
                </p>
              )}
            </div>

            {/* Security Badge */}
            <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Secure payment powered by industry-standard encryption</span>
            </div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="py-12 text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle className="w-16 h-16 text-green-500" />
            </motion.div>
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-2xl text-gray-800 mb-2"
            >
              Payment Successful!
            </motion.h3>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-gray-600 mb-4"
            >
              {packageCredits} credits have been added to your account
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex items-center justify-center gap-2 text-amber-600"
            >
              <Coins className="w-5 h-5" />
              <span className="text-xl">+{packageCredits} Credits</span>
            </motion.div>
          </motion.div>
        )}
      </DialogContent>
    </Dialog>
  );
}
