import { useState } from 'react';
import { motion } from 'motion/react';
import { FileText, Clock, Phone as PhoneIcon, User, Download, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

interface TranscriptPageProps {
  user: any;
}

// Mock data for transcripts
const mockTranscripts = [
  {
    id: '1',
    userName: 'John Doe',
    phone: '+1 (555) 123-4567',
    date: '2025-11-06',
    time: '10:30 AM',
    duration: '5:23',
    conversation: [
      { speaker: 'User', message: 'What is the GST rate for electronics?' },
      { speaker: 'Bruno', message: 'The GST rate for electronics is 18% for most electronic items.' },
      { speaker: 'User', message: 'And for mobile phones specifically?' },
      { speaker: 'Bruno', message: 'Mobile phones are taxed at 18% GST as well.' },
    ]
  },
  {
    id: '2',
    userName: 'Sarah Smith',
    phone: '+1 (555) 234-5678',
    date: '2025-11-05',
    time: '2:15 PM',
    duration: '3:45',
    conversation: [
      { speaker: 'User', message: 'How do I file my quarterly GST return?' },
      { speaker: 'Bruno', message: 'To file your quarterly GST return, log into the GST portal, navigate to Returns, select the appropriate quarter, and fill in Form GSTR-3B.' },
      { speaker: 'User', message: 'What is the deadline?' },
      { speaker: 'Bruno', message: 'The deadline is the 20th of the month following the quarter end.' },
    ]
  },
  {
    id: '3',
    userName: 'Michael Johnson',
    phone: '+1 (555) 345-6789',
    date: '2025-11-04',
    time: '9:00 AM',
    duration: '7:12',
    conversation: [
      { speaker: 'User', message: 'Can you explain input tax credit?' },
      { speaker: 'Bruno', message: 'Input Tax Credit (ITC) allows you to reduce your tax liability by claiming credit for the GST paid on purchases used for business purposes.' },
    ]
  },
  {
    id: '4',
    userName: 'Emily Davis',
    phone: '+1 (555) 456-7890',
    date: '2025-11-03',
    time: '11:45 AM',
    duration: '4:30',
    conversation: [
      { speaker: 'User', message: 'What are the tax benefits for startups?' },
      { speaker: 'Bruno', message: 'Startups recognized by DPIIT can avail 3 years of tax holiday within the first 10 years of incorporation under Section 80-IAC.' },
    ]
  },
  {
    id: '5',
    userName: 'Robert Wilson',
    phone: '+1 (555) 567-8901',
    date: '2025-11-02',
    time: '4:20 PM',
    duration: '6:05',
    conversation: [
      { speaker: 'User', message: 'How to register for GST?' },
      { speaker: 'Bruno', message: 'Visit the GST portal, click on "Register Now", fill in your details including PAN, business information, and bank details, then submit the application.' },
    ]
  },
];

export function TranscriptPage({ user }: TranscriptPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTranscript, setSelectedTranscript] = useState<any>(null);

  // Filter transcripts based on user role
  const userTranscripts = user?.role === 'admin' 
    ? mockTranscripts 
    : mockTranscripts.filter(t => t.userName === user?.name);

  const filteredTranscripts = userTranscripts.filter(t =>
    t.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.phone.includes(searchQuery)
  );

  const exportToExcel = () => {
    // In real app, this would generate and download an Excel file
    alert('Exporting to Excel...');
  };

  return (
    <div className="h-full p-8 overflow-auto">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl text-gray-800 mb-2">
              {user?.role === 'admin' ? 'All Call Transcripts' : 'My Call Transcripts'}
            </h2>
            <p className="text-gray-600">
              {user?.role === 'admin' 
                ? 'View and manage all AI conversation transcripts' 
                : 'View your AI conversation history'}
            </p>
          </div>
          <Button
            onClick={exportToExcel}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white gap-2"
          >
            <Download className="w-4 h-4" />
            Export to Excel
          </Button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by name or phone number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-11"
            />
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white"
          >
            <PhoneIcon className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">{userTranscripts.length}</p>
            <p className="text-blue-100">Total Calls</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white"
          >
            <User className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">{new Set(userTranscripts.map(t => t.userName)).size}</p>
            <p className="text-purple-100">Unique Users</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl p-6 text-white"
          >
            <Clock className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">27:15</p>
            <p className="text-pink-100">Total Duration</p>
          </motion.div>
        </div>

        {/* Transcripts Table */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl shadow-lg overflow-hidden"
        >
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User Name</TableHead>
                <TableHead>Phone Number</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTranscripts.map((transcript) => (
                <TableRow key={transcript.id}>
                  <TableCell>{transcript.userName}</TableCell>
                  <TableCell>{transcript.phone}</TableCell>
                  <TableCell>{transcript.date}</TableCell>
                  <TableCell>{transcript.time}</TableCell>
                  <TableCell>{transcript.duration}</TableCell>
                  <TableCell>
                    <Button
                      onClick={() => setSelectedTranscript(transcript)}
                      variant="outline"
                      size="sm"
                    >
                      View Transcript
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </motion.div>

        {/* Transcript Dialog */}
        <Dialog open={!!selectedTranscript} onOpenChange={() => setSelectedTranscript(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
            <DialogHeader>
              <DialogTitle>Call Transcript</DialogTitle>
              <DialogDescription>
                {selectedTranscript?.userName} • {selectedTranscript?.phone} • {selectedTranscript?.date} {selectedTranscript?.time}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 mt-4">
              {selectedTranscript?.conversation.map((msg: any, idx: number) => (
                <div
                  key={idx}
                  className={`p-4 rounded-lg ${
                    msg.speaker === 'User'
                      ? 'bg-blue-50 ml-8'
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white mr-8'
                  }`}
                >
                  <p className={msg.speaker === 'User' ? 'text-gray-800' : 'text-white'}>
                    {msg.message}
                  </p>
                  <p className={`text-xs mt-2 ${msg.speaker === 'User' ? 'text-gray-500' : 'text-blue-100'}`}>
                    {msg.speaker}
                  </p>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}