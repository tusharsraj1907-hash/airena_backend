
  # AI Voice Agent (Community)

  This is a code bundle for AI Voice Agent (Community). The original project is available at https://www.figma.com/design/HlbGKRMgVvfRGlVEe3JYoZ/AI-Voice-Agent--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  